from django.contrib import admin
from home.models import *
admin.register(Impoters,Expoters,Domestic_vendors,Domestic_buyers,Otp,Category,Product,ProductImage,Order,Elearning,Ecourses,LikeEcourse,LikeProduct,Super,Cart,Learn_more,Shipping_type,Buyers_adress,Plans,Letter,Offer,LetterImage,SingleChatRoom,SingleRoomMessage)(admin.ModelAdmin)
# Register your models here.

