import pyautogui as pg
import time
import random
while True:
    pg.hotkey('alt', 'tab')
    a=random.randint(1,120)
    print(a)
    time.sleep(a)