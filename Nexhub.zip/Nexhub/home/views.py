import os
from django.shortcuts import render, HttpResponse
from datetime import datetime,date
from home import serializers
from django.shortcuts import redirect
from django.utils import timezone
from moviepy.editor import VideoFileClip
from home.models import *  
from django.core.mail import send_mail
from django.contrib.auth.hashers import make_password, check_password
from django.contrib import messages
# import rest_framework
from pathlib import Path
import string
from django.views.decorators.csrf import csrf_exempt
BASE_DIR = Path(__file__).resolve().parent.parent
from django.conf import settings
from datetime import datetime, timedelta
from django.db.models import Q,F,Case, Value, When, FloatField,OuterRef, Subquery,CharField,Count,Func
import random
from rest_framework.decorators import api_view
from .serializers import *
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import generics
from rest_framework.response import Response

@csrf_exempt
# Create your views here.


################################################################ API ###############################################################################


@api_view(['POST'])
def signup(request):
    if request.POST.get('role') == "":
        return Response({"success":False, "message": "Role is required" }, status=status.HTTP_400_BAD_REQUEST)
    role = request.POST.get('role') 
    if request.POST.get('t_c') == "false" or request.POST.get("t_c") == "":
        return Response({"success":False, "message": "Please check Terms and Conditions." }, status=status.HTTP_400_BAD_REQUEST)
    if role == "impoters":
        serializer = ImpotersSerializer(data=request.data)
        if request.POST.get('first_name') == "":
            return Response({"success":False, "message": "First Name is required" }, status=status.HTTP_400_BAD_REQUEST) 
        first_name = request.POST.get('first_name')  
        last_name = request.POST.get('last_name')
        referral_code = request.POST.get('referral_code')
        if request.POST.get('firebase_token') == "":
            return Response({"success":False, "message": "Firebase Token is required" }, status=status.HTTP_400_BAD_REQUEST)  
        firebase_token = request.POST.get('firebase_token')  
        if request.POST.get('email_id') == "":
            return Response({"success":False, "message": "Email is required" }, status=status.HTTP_400_BAD_REQUEST)
        else:
            email_id = request.POST.get('email_id')
            ut = Impoters.objects.filter(email_id=email_id)
            if ut:
                return Response({"success":False, "message": "Email is already registered" }, status=status.HTTP_401_UNAUTHORIZED)
        email_id = request.POST.get('email_id')    
        if request.POST.get('phone_no') == "":
            return Response({"success":False, "message": "Phone is required" }, status=status.HTTP_400_BAD_REQUEST)
        else:
            phone_no = request.POST.get('phone_no')
            ut = Impoters.objects.filter(phone_no=phone_no)
            if ut:
                return Response({"success":False, "message": "Phone number is already Used" }, status=status.HTTP_401_UNAUTHORIZED)
        phone_no = request.POST.get('phone_no')
        if request.POST.get('password') == "":
            return Response({"success":False, "message": "Password is required" }, status=status.HTTP_400_BAD_REQUEST)
        password = request.POST.get('password')
        if request.POST.get('confirm_password') == "":
            return Response({"success":False, "message": "Confirm Password is required" }, status=status.HTTP_400_BAD_REQUEST)
        else:
            if request.POST.get('password') != request.POST.get('confirm_password'):
                return Response({"success":False, "message": "Confirm Password is not matched" }, status=status.HTTP_400_BAD_REQUEST)
        password = make_password(password)
        if serializer.is_valid():
            serializer.save()
            st = Impoters.objects.get(email_id=email_id)
            st.password = password
            st.save()
            serializer = ImpotersSerializer(st)
            return Response({"success":True, "message": "You registered Successfully","data":serializer.data}, status=status.HTTP_200_OK)
    elif role == "expoters":
        serializer = ExpotersSerializer(data=request.data)
        if request.POST.get('first_name') == "":
            return Response({"success":False, "message": "First Name is required" }, status=status.HTTP_400_BAD_REQUEST) 
        first_name = request.POST.get('first_name')  
        last_name = request.POST.get('last_name') 
        referral_code = request.POST.get('referral_code')
        if request.POST.get('firebase_token') == "":
            return Response({"success":False, "message": "Firebase Token is required" }, status=status.HTTP_400_BAD_REQUEST)  
        firebase_token = request.POST.get('firebase_token')  
        if request.POST.get('email_id') == "":
            return Response({"success":False, "message": "Email is required" }, status=status.HTTP_400_BAD_REQUEST)
        else:
            email_id = request.POST.get('email_id')
            ut = Expoters.objects.filter(email_id=email_id)
            if ut:
                return Response({"success":False, "message": "Email is already registered" }, status=status.HTTP_401_UNAUTHORIZED)
        email_id = request.POST.get('email_id')    
        if request.POST.get('phone_no') == "":
            return Response({"success":False, "message": "Phone is required" }, status=status.HTTP_400_BAD_REQUEST)
        else:
            phone_no = request.POST.get('phone_no')
            ut = Expoters.objects.filter(phone_no=phone_no)
            if ut:
                return Response({"success":False, "message": "Phone number is already Used" }, status=status.HTTP_401_UNAUTHORIZED)
        phone_no = request.POST.get('phone_no')
        if request.POST.get('password') == "":
            return Response({"success":False, "message": "Password is required" }, status=status.HTTP_400_BAD_REQUEST)
        password = request.POST.get('password')
        if request.POST.get('confirm_password') == "":
            return Response({"success":False, "message": "Confirm Password is required" }, status=status.HTTP_400_BAD_REQUEST)
        else:
            if request.POST.get('password') != request.POST.get('confirm_password'):
                return Response({"success":False, "message": "Confirm Password is not matched" }, status=status.HTTP_400_BAD_REQUEST)
        password = make_password(password)
        if serializer.is_valid():
            serializer.save()
            st = Expoters.objects.get(email_id=email_id)
            st.password = password
            st.save()
            serializer = ExpotersSerializer(st)
            return Response({"success":True, "message": "You registered Successfully","data":serializer.data}, status=status.HTTP_200_OK)     
    else:
        return Response({"success":False, "message": "Role is invalid" }, status=status.HTTP_401_UNAUTHORIZED)


@api_view(['POST'])
def signup_with_google(request):
    if request.POST.get('role') == "":
        return Response({"success":False, "message": "Role is required" }, status=status.HTTP_400_BAD_REQUEST)
    role = request.POST.get('role') 
    if request.POST.get('t_c') == "false" or request.POST.get("t_c") == "":
        return Response({"success":False, "message": "Please check Terms and Conditions." }, status=status.HTTP_400_BAD_REQUEST)
    if request.POST.get('device_token') == "":
        return Response({"success":False, "message": "Device Token is required" }, status=status.HTTP_400_BAD_REQUEST)
    if role == "impoters":
        serializer = ImpotersSerializer(data=request.data)
        if request.POST.get('first_name') == "":
            return Response({"success":False, "message": "First Name is required" }, status=status.HTTP_400_BAD_REQUEST) 
        first_name = request.POST.get('first_name')  
        last_name = request.POST.get('last_name') 
        if request.POST.get('firebase_token') == "":
            return Response({"success":False, "message": "Firebase Token is required" }, status=status.HTTP_400_BAD_REQUEST)  
        firebase_token = request.POST.get('firebase_token')  
        if request.POST.get('email_id') == "":
            return Response({"success":False, "message": "Email is required" }, status=status.HTTP_400_BAD_REQUEST)
        else:
            email_id = request.POST.get('email_id')
            ut = Impoters.objects.filter(email_id=email_id)
            if ut:
                return Response({"success":False, "message": "Email is already registered" }, status=status.HTTP_401_UNAUTHORIZED)
        email_id = request.POST.get('email_id')    
        if request.POST.get('social_id') == "":
            return Response({"success":False, "message": "Social Id is required" }, status=status.HTTP_400_BAD_REQUEST)
        social_id = request.POST.get('social_id')
        if serializer.is_valid():
            serializer.save()
            st = Impoters.objects.get(email_id=email_id)
            st.save()
            serializer = ImpotersSerializer(st)
            return Response({"success":True, "message": "You registered Successfully","data":serializer.data}, status=status.HTTP_200_OK)
    elif role == "expoters":
        serializer = ExpotersSerializer(data=request.data)
        if request.POST.get('first_name') == "":
            return Response({"success":False, "message": "First Name is required" }, status=status.HTTP_400_BAD_REQUEST) 
        first_name = request.POST.get('first_name')  
        last_name = request.POST.get('last_name') 
        if request.POST.get('firebase_token') == "":
            return Response({"success":False, "message": "Firebase Token is required" }, status=status.HTTP_400_BAD_REQUEST)  
        firebase_token = request.POST.get('firebase_token')  
        if request.POST.get('email_id') == "":
            return Response({"success":False, "message": "Email is required" }, status=status.HTTP_400_BAD_REQUEST)
        else:
            email_id = request.POST.get('email_id')
            ut = Expoters.objects.filter(email_id=email_id)
            if ut:
                return Response({"success":False, "message": "Email is already registered" }, status=status.HTTP_401_UNAUTHORIZED)
        email_id = request.POST.get('email_id')    
        if request.POST.get('social_id') == "":
            return Response({"success":False, "message": "Social Id is required" }, status=status.HTTP_400_BAD_REQUEST)
        social_id = request.POST.get('social_id')
        if serializer.is_valid():
            serializer.save()
            st = Expoters.objects.get(email_id=email_id)
            st.save()
            serializer = ExpotersSerializer(st)
            return Response({"success":True, "message": "You registered Successfully","data":serializer.data}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Role is invalid" }, status=status.HTTP_401_UNAUTHORIZED)



@api_view(['POST'])
def login_user(request):
    if request.POST.get('role') == "":
        return Response({"success":False, "message": "Role is required" }, status=status.HTTP_400_BAD_REQUEST)
    role = request.POST.get('role')
    if role == "impoters":    
        if request.POST.get('email_id') == "":
            return Response({"success":False, "message": "Email is required" }, status=status.HTTP_400_BAD_REQUEST)
        email_id = request.POST.get('email_id')
        if request.POST.get('password') == "":
            return Response({"success":False, "message": "Password is required" }, status=status.HTTP_400_BAD_REQUEST)
        password = request.POST.get('password')
        if Impoters.objects.filter(email_id=email_id):
            impo_user = Impoters.objects.filter(email_id=email_id).first()
            pass1 = impo_user.password
            if check_password(password, pass1):
                serializer = ImpotersSerializer(impo_user)
                return Response({"success":True, "message": "You are logged in","data":serializer.data }, status=status.HTTP_200_OK)
            else:
                return Response({"success":False, "message": "Password is Invalid" }, status=status.HTTP_401_UNAUTHORIZED)
        else:
            return Response({"success":False, "message": "Email is Invalid" }, status=status.HTTP_401_UNAUTHORIZED)
    if role == "expoters":    
        if request.POST.get('email_id') == "":
            return Response({"success":False, "message": "Email is required" }, status=status.HTTP_400_BAD_REQUEST)
        email_id = request.POST.get('email_id')
        if request.POST.get('password') == "":
            return Response({"success":False, "message": "Password is required" }, status=status.HTTP_400_BAD_REQUEST)
        password = request.POST.get('password')
        if Expoters.objects.filter(email_id=email_id):
            impo_user = Expoters.objects.filter(email_id=email_id).first()
            pass1 = impo_user.password
            if check_password(password, pass1):
                serializer = ExpotersSerializer(impo_user)
                return Response({"success":True, "message": "You are logged in","data":serializer.data }, status=status.HTTP_200_OK)
            else:
                return Response({"success":False, "message": "Password is Invalid" }, status=status.HTTP_401_UNAUTHORIZED)
        else:
            return Response({"success":False, "message": "Email is Invalid" }, status=status.HTTP_401_UNAUTHORIZED)
    if role == "domestic_vendors":    
        if request.POST.get('email_id') == "":
            return Response({"success":False, "message": "Email is required" }, status=status.HTTP_400_BAD_REQUEST)
        email_id = request.POST.get('email_id')
        if request.POST.get('password') == "":
            return Response({"success":False, "message": "Password is required" }, status=status.HTTP_400_BAD_REQUEST)
        password = request.POST.get('password')
        if Domestic_vendors.objects.filter(email_id=email_id):
            impo_user = Domestic_vendors.objects.filter(email_id=email_id).first()
            pass1 = impo_user.password
            if check_password(password, pass1):
                serializer = Domestic_vendorsSerializer(impo_user)
                return Response({"success":True, "message": "You are logged in","data":serializer.data }, status=status.HTTP_200_OK)
            else:
                return Response({"success":False, "message": "Password is Invalid" }, status=status.HTTP_401_UNAUTHORIZED)
        else:
            return Response({"success":False, "message": "Email is Invalid" }, status=status.HTTP_401_UNAUTHORIZED)
    if role == "domestic_buyers":    
        if request.POST.get('email_id') == "":
            return Response({"success":False, "message": "Email is required" }, status=status.HTTP_400_BAD_REQUEST)
        email_id = request.POST.get('email_id')
        if request.POST.get('password') == "":
            return Response({"success":False, "message": "Password is required" }, status=status.HTTP_400_BAD_REQUEST)
        password = request.POST.get('password')
        if Domestic_buyers.objects.filter(email_id=email_id):
            impo_user = Domestic_buyers.objects.filter(email_id=email_id).first()
            pass1 = impo_user.password
            if check_password(password, pass1):
                serializer = Domestic_buyersSerializer(impo_user)
                return Response({"success":True, "message": "You are logged in","data":serializer.data }, status=status.HTTP_200_OK)
            else:
                return Response({"success":False, "message": "Password is Invalid" }, status=status.HTTP_401_UNAUTHORIZED)
        else:
            return Response({"success":False, "message": "Email is Invalid" }, status=status.HTTP_401_UNAUTHORIZED)
    else:
        return Response({"success":False, "message": "Role is invalid" }, status=status.HTTP_401_UNAUTHORIZED)


@api_view(['POST'])
def login_with_google(request):
    if request.POST.get('role') == "":
        return Response({"success":False, "message": "Role is required" }, status=status.HTTP_400_BAD_REQUEST)
    role = request.POST.get('role')
    if role == "impoters":    
        if request.POST.get('firebase_token') == "":
            return Response({"success":False, "message": "Firebase Token is required" }, status=status.HTTP_400_BAD_REQUEST)  
        firebase_token = request.POST.get('firebase_token') 
        email_id = request.POST.get('email_id')
        social_id = request.POST.get('social_id')
        serializer = ImpotersSerializer(data=request.data)
        if email_id == "":
            return Response({"success":False, "message": "Email Id is required" }, status=status.HTTP_400_BAD_REQUEST)
        if social_id == "":
            return Response({"success":False, "message": "Social is required" }, status=status.HTTP_400_BAD_REQUEST)
        if (Impoters.objects.filter(email_id=email_id,social_id=social_id,status=1)):
            st = Impoters.objects.get(email_id=email_id)
            st.firebase_token = firebase_token
            st.save()
            serializer = ImpotersSerializer(st)
            return Response({"success":True, "message": "you Login successfully","data":serializer.data}, status=status.HTTP_200_OK)
        else:
            return Response({"success":False, "message": "You are not register with this credential."},status=status.HTTP_401_UNAUTHORIZED) 
    if role == "expoters": 
        if request.POST.get('firebase_token') == "":
            return Response({"success":False, "message": "Firebase Token is required" }, status=status.HTTP_400_BAD_REQUEST)  
        firebase_token = request.POST.get('firebase_token') 
        email_id = request.POST.get('email_id')
        social_id = request.POST.get('social_id')
        serializer = ExpotersSerializer(data=request.data)
        if email_id == "":
            return Response({"success":False, "message": "Email Id is required" }, status=status.HTTP_400_BAD_REQUEST)
        if social_id == "":
            return Response({"success":False, "message": "Social is required" }, status=status.HTTP_400_BAD_REQUEST)
        if (Expoters.objects.filter(email_id=email_id,social_id=social_id,status=1)):
            st = Expoters.objects.get(email_id=email_id)
            st.firebase_token = firebase_token
            st.save()
            serializer = ExpotersSerializer(st)
            return Response({"success":True, "message": "you Login successfully","data":serializer.data}, status=status.HTTP_200_OK)
        else:
            return Response({"success":False, "message": "You are not register with this credential."},status=status.HTTP_401_UNAUTHORIZED) 
       

@api_view(['POST'])
def get_impoters(request):
    if request.POST.get('importers_id') == "":
        return Response({"success":False, "message": "Impoters Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    importers_id = request.POST.get('importers_id') 
    if Impoters.objects.filter(importers_id=importers_id):
        impoters_user = Impoters.objects.filter(importers_id=importers_id).first()
        serializer = ImpotersSerializer(impoters_user)
        return Response({"success":True, "message": "Your data is here","data":serializer.data }, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Importers Id is Invalid" }, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['POST'])
def get_expoters(request):
    if request.POST.get('expoters_id') == "":
        return Response({"success":False, "message": "Expoters Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    expoters_id = request.POST.get('expoters_id')
    if Expoters.objects.filter(expoters_id=expoters_id):
        expoters_user = Expoters.objects.filter(expoters_id=expoters_id).first()
        serializer = ExpotersSerializer(expoters_user)
        return Response({"success":True, "message": "Your data is here","data":serializer.data }, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Expoters Id is Invalid" }, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['POST'])
def get_domestic_vendors(request):
    if request.POST.get('domestic_vendor_id') == "":
        return Response({"success":False, "message": "Domestic Vendors Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_vendor_id = request.POST.get('domestic_vendor_id')
    if Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id):
        domestic_vendors_user = Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id).first()
        serializer = Domestic_vendorsSerializer(domestic_vendors_user)
        return Response({"success":True, "message": "Your data is here","data":serializer.data }, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Domestic Vendors Id is Invalid" }, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['POST'])
def get_domestic_buyers(request):
    if request.POST.get('domestic_buyers_id') == "":
        return Response({"success":False, "message": "Domestic Buyers Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_buyers_id = request.POST.get('domestic_buyers_id')
    if Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id):
        domestic_buyesrs_user = Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first()
        serializer = Domestic_buyersSerializer(domestic_buyesrs_user)
        return Response({"success":True, "message": "Your data is here","data":serializer.data }, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Domestic Buyers Id is Invalid" }, status=status.HTTP_401_UNAUTHORIZED)




@api_view(['POST'])
def update_importers(request):
    if request.POST.get('importers_id') == "":
        return Response({"success":False, "message": "Impoters Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    importers_id = request.POST.get('importers_id')
    if request.POST.get('first_name') == "":
        return Response({"success":False, "message": "First Name is required" }, status=status.HTTP_400_BAD_REQUEST) 
    first_name = request.POST.get('first_name')  
    if request.POST.get('last_name') == "":
        return Response({"success":False, "message": "Last Name is required" }, status=status.HTTP_400_BAD_REQUEST) 
    last_name = request.POST.get('last_name')
    if request.POST.get('gender') == "":
        return Response({"success":False, "message": "Gender is required" }, status=status.HTTP_400_BAD_REQUEST)  
    gender = request.POST.get('gender')  
    user_img = request.FILES.get('user_img')
    if Impoters.objects.filter(importers_id=importers_id):
        impoters_user = Impoters.objects.filter(importers_id=importers_id).first()
        impoters_user.first_name = first_name
        impoters_user.last_name = last_name
        impoters_user.gender = gender
        if user_img:
            impoters_user.user_img = user_img
        impoters_user.save()
        impoters_user = Impoters.objects.filter(importers_id=importers_id).first()
        serializer = ImpotersSerializer(impoters_user)
        return Response({"success":True, "message": "You updated Successfully","data":serializer.data }, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Enter Valid Importes Id" }, status=status.HTTP_401_UNAUTHORIZED)


@api_view(['POST'])
def update_expoters(request):
    if request.POST.get('expoters_id') == "":
        return Response({"success":False, "message": "Expoters Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    expoters_id = request.POST.get('expoters_id')
    if request.POST.get('first_name') == "":
        return Response({"success":False, "message": "First Name is required" }, status=status.HTTP_400_BAD_REQUEST) 
    first_name = request.POST.get('first_name')  
    if request.POST.get('last_name') == "":
        return Response({"success":False, "message": "Last Name is required" }, status=status.HTTP_400_BAD_REQUEST) 
    last_name = request.POST.get('last_name') 
    if request.POST.get('gender') == "":
        return Response({"success":False, "message": "Gender is required" }, status=status.HTTP_400_BAD_REQUEST)  
    gender = request.POST.get('gender')  
    if request.FILES.get('user_img') == "":
        user_img = ""
    else:
        user_img = request.FILES.get('user_img')
    if request.FILES.get('business_logo') == "":
        business_logo = ""
    else:
        business_logo = request.FILES.get('business_logo')
    if request.FILES.get('business_cover') == "":
        business_cover = ""
    else:
        business_cover = request.FILES.get('business_cover')
    if request.POST.get('business_name') == "":
        business_name = ""
    else:
        business_name = request.POST.get('business_name') 
    if request.POST.get('store_name') == "":
        store_name = ""
    else:
        store_name = request.POST.get('store_name') 
    if request.POST.get('about') == "":
        about = ""
    else:
        about = request.POST.get('about') 
    if request.POST.get('store_location') == "":
        store_location = "" 
    else:
        store_location = request.POST.get('store_location') 
    if request.POST.get('type_of_product') == "":
        type_of_product = ""
    else: 
        type_of_product = request.POST.get('type_of_product') 
    if request.POST.get('import_code') == "":
        import_code = "" 
    else:
        import_code = request.POST.get('import_code') 
    if request.FILES.get('business_document') == "":
        business_document = ""
    else:
        business_document = request.FILES.get('business_document')
    if Expoters.objects.filter(expoters_id=expoters_id):
        expoters_user = Expoters.objects.filter(expoters_id=expoters_id).first()
        expoters_user.first_name = first_name
        expoters_user.last_name = last_name
        expoters_user.user_img = user_img
        expoters_user.business_logo = business_logo
        expoters_user.business_cover = business_cover
        expoters_user.business_name = business_name
        expoters_user.store_name = store_name
        expoters_user.gender = gender
        expoters_user.about = about
        expoters_user.store_location = store_location
        expoters_user.type_of_product = type_of_product
        expoters_user.import_code = import_code
        expoters_user.business_document = business_document
        expoters_user.save()
        expoters_user = Expoters.objects.filter(expoters_id=expoters_id).first()
        serializer = ExpotersSerializer(expoters_user)
        return Response({"success":True, "message": "You updated Successfully","data":serializer.data }, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Enter Valid Expoters Id" }, status=status.HTTP_401_UNAUTHORIZED)


@api_view(['POST'])
def add_delivery_capacity(request):
    if request.POST.get('expoters_id') == "":
        return Response({"success":False, "message": "Expoters Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    expoters_id = request.POST.get('expoters_id')
    if Expoters.objects.filter(expoters_id=expoters_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Expoters Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('category_id') == "":
        return Response({"success":False, "message": "Category Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    category_id = request.POST.get('category_id')
    if Category.objects.filter(category_id=category_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Category Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('product_id') == "":
        return Response({"success":False, "message": "Product Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    product_id = request.POST.get('product_id')
    if Product.objects.filter(product_id=product_id,status=1).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Product Id" }, status=status.HTTP_401_UNAUTHORIZED)
    prot = Product.objects.filter(product_id=product_id).first()
    if request.POST.get('delivery_capacity') == "":
        return Response({"success":False, "message": "Delivery Capacity is required" }, status=status.HTTP_400_BAD_REQUEST) 
    delivery_capacity = request.POST.get('delivery_capacity')
    pc = Product.objects.create(product_name=prot.product_name,category_id=prot.category_id,cost=prot.cost,about=prot.about,variant=prot.variant,variant_quantity=delivery_capacity,product_add_by="Export",date=timezone.now(),expoters_id_id=expoters_id)
    return Response({"success":True, "message": "Product Delivery capacity added successfully."}, status=status.HTTP_200_OK)

    



@api_view(['POST'])
def update_domestic_vendors(request):
    if request.POST.get('domestic_vendor_id') == "":
        return Response({"success":False, "message": "Domestic Vendors Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_vendor_id = request.POST.get('domestic_vendor_id')
    if request.POST.get('first_name') == "":
        return Response({"success":False, "message": "First Name is required" }, status=status.HTTP_400_BAD_REQUEST) 
    first_name = request.POST.get('first_name')  
    if request.POST.get('last_name') == "":
        return Response({"success":False, "message": "Last Name is required" }, status=status.HTTP_400_BAD_REQUEST) 
    last_name = request.POST.get('last_name') 
    if request.POST.get('gender') == "":
        return Response({"success":False, "message": "Gender is required" }, status=status.HTTP_400_BAD_REQUEST)  
    gender = request.POST.get('gender')  
    if request.FILES.get('user_img') == "":
        user_img = ""
    else:
        user_img = request.FILES.get('user_img')
    if request.FILES.get('business_logo') == "":
        business_logo = ""
    else:
        business_logo = request.FILES.get('business_logo')
    if request.FILES.get('business_cover') == "":
        business_cover = ""
    else:
        business_cover = request.FILES.get('business_cover')
    if request.POST.get('business_name') == "":
        business_name = ""
    else:
        business_name = request.POST.get('business_name') 
    if request.POST.get('store_name') == "":
        store_name = ""
    else:
        store_name = request.POST.get('store_name') 
    if request.POST.get('about') == "":
        about = ""
    else:
        about = request.POST.get('about') 
    if request.POST.get('store_location') == "":
        store_location = "" 
    else:
        store_location = request.POST.get('store_location') 
    if request.POST.get('type_of_product') == "":
        type_of_product = ""
    else: 
        type_of_product = request.POST.get('type_of_product') 
    if request.FILES.get('business_document') == "":
        business_document = ""
    else:
        business_document = request.FILES.get('business_document')
    if Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id):
        domestic_vendor_user = Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id).first()
        domestic_vendor_user.first_name = first_name
        domestic_vendor_user.last_name = last_name
        if user_img:
            domestic_vendor_user.user_img = user_img
        domestic_vendor_user.business_logo = business_logo
        domestic_vendor_user.business_cover = business_cover
        domestic_vendor_user.business_name = business_name
        domestic_vendor_user.store_name = store_name
        domestic_vendor_user.about = about
        domestic_vendor_user.gender = gender
        domestic_vendor_user.store_location = store_location
        domestic_vendor_user.type_of_product = type_of_product
        domestic_vendor_user.business_document = business_document
        domestic_vendor_user.save()
        domestic_vendor_user = Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id).first()
        serializer = Domestic_vendorsSerializer(domestic_vendor_user)
        return Response({"success":True, "message": "You updated Successfully","data":serializer.data }, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Enter Valid Domestic Vendors Id" }, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['POST'])
def update_domestic_buyesrs(request):
    if request.POST.get('domestic_buyers_id') == "":
        return Response({"success":False, "message": "Domestic Buyers Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_buyers_id = request.POST.get('domestic_buyers_id')
    if request.POST.get('first_name') == "":
        return Response({"success":False, "message": "First Name is required" }, status=status.HTTP_400_BAD_REQUEST) 
    first_name = request.POST.get('first_name')  
    if request.POST.get('last_name') == "":
        return Response({"success":False, "message": "Last Name is required" }, status=status.HTTP_400_BAD_REQUEST) 
    last_name = request.POST.get('last_name')
    if request.POST.get('gender') == "":
        return Response({"success":False, "message": "Gender is required" }, status=status.HTTP_400_BAD_REQUEST)  
    gender = request.POST.get('gender')  
    if request.FILES.get('user_img') == "":
        user_img = ""
    else:
        user_img = request.FILES.get('user_img')
    if Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id):
        domestic_buyers_user = Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first()
        domestic_buyers_user.first_name = first_name
        domestic_buyers_user.last_name = last_name
        domestic_buyers_user.gender = gender
        if user_img:
            domestic_buyers_user.user_img = user_img
        domestic_buyers_user.save()
        domestic_buyers_user = Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first()
        serializer = Domestic_buyersSerializer(domestic_buyers_user)
        return Response({"success":True, "message": "You updated Successfully","data":serializer.data }, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Enter Valid Domestic Buyers Id" }, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['POST'])
def forgot_password(request):   
    if request.POST.get('email_id') == "":
        return Response({"success":False, "message": "Email is required" }, status=status.HTTP_400_BAD_REQUEST)
    email_id = request.POST.get('email_id')
    if Impoters.objects.filter(email_id=email_id):
        email_from = settings.EMAIL_HOST_USER
        recipient_list = [email_id]
        subject = "One Time Password for Nexhub"
        otp = str(random.randint(1000, 9999))
        message = "Your one time OTP is "
        ms=message + otp
        if Otp.objects.filter(email_id=email_id).exists():
            nttp = Otp.objects.filter(email_id=email_id).first()
            samma = timezone.now()
            nttp.otp = otp
            nttp.date = samma
            nttp.status = 1
            nttp.save()
        else:
            query = Otp(email_id=email_id,otp=otp,date=timezone.now())
            query.save()
        send_mail( subject, ms, email_from, recipient_list)
        return Response({"success":True, "message": "You have sent the OTP" }, status=status.HTTP_200_OK)
    elif Expoters.objects.filter(email_id=email_id):
        email_from = settings.EMAIL_HOST_USER
        recipient_list = [email_id]
        subject = "One Time Password for Nexhub"
        otp = str(random.randint(1000, 9999))
        message = "Your one time OTP is "
        ms=message + otp
        if Otp.objects.filter(email_id=email_id).exists():
            nttp = Otp.objects.filter(email_id=email_id).first()
            samma = timezone.now()
            nttp.otp = otp
            nttp.date = samma
            nttp.status = 1
            nttp.save()
        else:
            query = Otp(email_id=email_id,otp=otp,date=timezone.now())
            query.save()
        send_mail( subject, ms, email_from, recipient_list)
        return Response({"success":True, "message": "You have sent the OTP" }, status=status.HTTP_200_OK)
    elif Domestic_vendors.objects.filter(email_id=email_id):
        email_from = settings.EMAIL_HOST_USER
        recipient_list = [email_id]
        subject = "One Time Password for Nexhub"
        otp = str(random.randint(1000, 9999))
        message = "Your one time OTP is "
        ms=message + otp
        if Otp.objects.filter(email_id=email_id).exists():
            nttp = Otp.objects.filter(email_id=email_id).first()
            samma = timezone.now()
            nttp.otp = otp
            nttp.date = samma
            nttp.status = 1
            nttp.save()
        else:
            query = Otp(email_id=email_id,otp=otp,date=timezone.now())
            query.save()
        send_mail( subject, ms, email_from, recipient_list)
        return Response({"success":True, "message": "You have sent the OTP" }, status=status.HTTP_200_OK)
    elif Domestic_buyers.objects.filter(email_id=email_id):
        email_from = settings.EMAIL_HOST_USER
        recipient_list = [email_id]
        subject = "One Time Password for Nexhub"
        otp = str(random.randint(1000, 9999))
        message = "Your one time OTP is "
        ms=message + otp
        if Otp.objects.filter(email_id=email_id).exists():
            nttp = Otp.objects.filter(email_id=email_id).first()
            samma = timezone.now()
            nttp.otp = otp
            nttp.date = samma
            nttp.status = 1
            nttp.save()
        else:
            query = Otp(email_id=email_id,otp=otp,date=timezone.now())
            query.save()
        send_mail( subject, ms, email_from, recipient_list)
        return Response({"success":True, "message": "You have sent the OTP" }, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Email is Invalid" }, status=status.HTTP_401_UNAUTHORIZED)
        

@api_view(['POST'])
def email_otp_verify(request):
    if request.POST.get('otp') == "":
        return Response({"success":False, "message": "Otp is required" }, status=status.HTTP_400_BAD_REQUEST) 
    otp = request.POST.get('otp')
    if request.POST.get('email_id') == "":
        return Response({"success":False, "message": "Email Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    email_id = request.POST.get('email_id')
    if Otp.objects.filter(otp=otp,email_id=email_id):
        ddty = Otp.objects.filter(otp=otp,email_id=email_id).first()
        start_time = ddty.date
        end_time = start_time + timedelta(minutes=int(10))
        end_time = datetime.strftime(end_time, '%Y-%m-%d %H:%M:%S')
        over = datetime.now()
        over = datetime.strftime(over, '%Y-%m-%d %H:%M:%S')
        print(ddty.date)
        if over >= end_time:
            return Response({"success":False, "message": "OTP Expired" }, status=status.HTTP_401_UNAUTHORIZED)
        return Response({"success":True, "message": "Otp verified"}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "invalid OTP"}, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['POST'])
def change_password(request):
    if request.POST.get('email_id') == "":
        return Response({"success":False, "message": "Email Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    email_id = request.POST.get('email_id')
    if request.POST.get('new_password') == "":
        return Response({"success":False, "message": "New Password is required" }, status=status.HTTP_400_BAD_REQUEST)
    new_password = request.POST.get('new_password')
    if request.POST.get('confirm_password') == "":
        return Response({"success":False, "message": "Confirm Password is required" }, status=status.HTTP_400_BAD_REQUEST)
    confirm_password = request.POST.get('confirm_password')
    if new_password != confirm_password:
        return Response({"success":False, "message": "Passwords do not match" }, status=status.HTTP_401_UNAUTHORIZED)
    new_password = make_password(new_password)
    if Impoters.objects.filter(email_id=email_id):
        chan = Impoters.objects.filter(email_id=email_id).first()
        chan.password = new_password
        chan.save()
        return Response({"success":True, "message": "Password changed"}, status=status.HTTP_200_OK)
    if Expoters.objects.filter(email_id=email_id):
        chan = Expoters.objects.filter(email_id=email_id).first()
        chan.password = new_password
        chan.save()
        return Response({"success":True, "message": "Password changed"}, status=status.HTTP_200_OK)
    if Domestic_vendors.objects.filter(email_id=email_id):
        chan = Domestic_vendors.objects.filter(email_id=email_id).first()
        chan.password = new_password
        chan.save()
        return Response({"success":True, "message": "Password changed"}, status=status.HTTP_200_OK)
    if Domestic_buyers.objects.filter(email_id=email_id):
        chan = Domestic_buyers.objects.filter(email_id=email_id).first()
        chan.password = new_password
        chan.save()
        return Response({"success":True, "message": "Password changed"}, status=status.HTTP_200_OK)
    


@api_view(['Get'])
def category_list(request):
    ct = Category.objects.all()
    if ct:
        serializers = CategorySerializer(ct, many=True)
        return Response({"success":True, "message": "Here is your category list","data":serializers.data}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Category Found" }, status=status.HTTP_401_UNAUTHORIZED)




@api_view(['POST'])
def product_list(request):
    if request.POST.get('category_id') == "":
        return Response({"success":False, "message": "Category Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    category_id = request.POST.get('category_id')
    if Category.objects.filter(category_id=category_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Category Id" }, status=status.HTTP_401_UNAUTHORIZED)
    pt = Product.objects.filter(category_id=category_id,status=1)
    if pt:
        lst = []
        for i in pt:
            dict = {"product_id":i.product_id,"product_name":i.product_name}
            lst.append(dict)
        return Response({"success":True, "message": "Here is your Product list","product_list":lst}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Product Found" }, status=status.HTTP_401_UNAUTHORIZED)



@api_view(['POST'])
def add_product(request):
    if request.POST.get('domestic_vendor_id') == "":
        return Response({"success":False, "message": "Domestic Vendors Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_vendor_id = request.POST.get('domestic_vendor_id')
    if Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Domestic Vendors Id" }, status=status.HTTP_401_UNAUTHORIZED)
    else:
        dv = Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id).first()
    if request.POST.get('product_name') == "":
        return Response({"success":False, "message": "Product Name is required" }, status=status.HTTP_400_BAD_REQUEST) 
    product_name = request.POST.get('product_name')
    if request.POST.get('category_id') == "":
        return Response({"success":False, "message": "Category Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    category_id = request.POST.get('category_id')
    if Category.objects.filter(category_id=category_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Category Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('cost') == "":
        return Response({"success":False, "message": "Cost is required" }, status=status.HTTP_400_BAD_REQUEST) 
    cost = request.POST.get('cost')
    if request.POST.get('about') == "":
        return Response({"success":False, "message": "Description is required" }, status=status.HTTP_400_BAD_REQUEST) 
    about = request.POST.get('about')
    if request.POST.get('variant') == "":
        return Response({"success":False, "message": "Variant is required" }, status=status.HTTP_400_BAD_REQUEST) 
    variant = request.POST.get('variant')
    if request.POST.get('variant_quantity') == "":
        return Response({"success":False, "message": "Variant Quantity is required" }, status=status.HTTP_400_BAD_REQUEST) 
    variant_quantity = request.POST.get('variant_quantity')
    if request.FILES.getlist('product_image[]') == "":
        return Response({"success":False, "message": "Product Image is required" }, status=status.HTTP_400_BAD_REQUEST) 
    product_image = request.FILES.getlist('product_image[]')
    product_add_by = "Domestic"
    pt = Product.objects.create(product_name=product_name,category_id_id=category_id,cost=cost,about=about,variant=variant,variant_quantity=variant_quantity,date=timezone.now(),product_add_by=product_add_by,domestic_vendor_id_id=domestic_vendor_id)
    l = len(product_image)
    if l > 4:
        return Response({"success":False, "message": "You only able to insert only four Image" }, status=status.HTTP_401_UNAUTHORIZED)
    for i in range(l):
        image = product_image[i]
        ProductImage.objects.create(product_id_id = pt.product_id, image=image)
    return Response({"success":True, "message": "Product Created" }, status=status.HTTP_200_OK)




@api_view(['POST'])
def edit_product(request):
    if request.POST.get('product_id') == "":
        return Response({"success":False, "message": "Product Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    product_id = request.POST.get('product_id')
    if Product.objects.filter(product_id=product_id,status=1).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Product Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('product_name') == "":
        return Response({"success":False, "message": "Product Name is required" }, status=status.HTTP_400_BAD_REQUEST) 
    product_name = request.POST.get('product_name')
    if request.POST.get('category_id') == "":
        return Response({"success":False, "message": "Category Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    category_id = request.POST.get('category_id')
    if Category.objects.filter(category_id=category_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Category Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('cost') == "":
        return Response({"success":False, "message": "Cost is required" }, status=status.HTTP_400_BAD_REQUEST) 
    cost = request.POST.get('cost')
    if request.POST.get('about') == "":
        return Response({"success":False, "message": "Description is required" }, status=status.HTTP_400_BAD_REQUEST) 
    about = request.POST.get('about')
    if request.POST.get('variant') == "":
        return Response({"success":False, "message": "Variant is required" }, status=status.HTTP_400_BAD_REQUEST) 
    variant = request.POST.get('variant')
    if request.POST.get('variant_quantity') == "":
        return Response({"success":False, "message": "Variant Quantity is required" }, status=status.HTTP_400_BAD_REQUEST) 
    variant_quantity = request.POST.get('variant_quantity')
    if request.FILES.getlist('product_image[]') == "":
        return Response({"success":False, "message": "Product Image is required" }, status=status.HTTP_400_BAD_REQUEST) 
    product_image = request.FILES.getlist('product_image[]')
    product = Product.objects.filter(product_id=product_id).first()
    product.product_name = product_name
    product.category_id_id = category_id
    product.cost = cost
    product.about = about
    product.variant = variant
    product.variant_quantity = variant_quantity
    product.save()
    lst = []
    pti = ProductImage.objects.filter(product_id=product_id)
    for i in pti:
        lst.append(i.image)
    for i in product_image:
        if (ProductImage.objects.filter(image=i,product_id=product_id)):
            lst.remove(i)
        else:
            ProductImage.objects.create(image=i,product_id_id=product_id)
    if lst:
        for i in lst:
            ProductImage.objects.filter(product_id=product_id,image=i).delete()
    return Response({"success":True, "message": "Product Update successsfully" }, status=status.HTTP_200_OK)


@api_view(['POST'])
def get_product(request):
    serializer = ProductSerializer(data=request.data)
    if request.POST.get('product_id') == "":
        return Response({"success":False, "message": "Product Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    product_id = request.POST.get('product_id')
    if Product.objects.filter(product_id=product_id,status=1).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Product Id" }, status=status.HTTP_401_UNAUTHORIZED)
    pt = Product.objects.filter(product_id=product_id,status=1).first()
    pti = ProductImage.objects.filter(product_id=product_id)
    serializer = ProductSerializer(pt)
    x = serializer.data
    return Response({"success":True, "message": "Product Detail","product":x }, status=status.HTTP_200_OK)

@api_view(['POST'])
def inventory_list(request):
    if request.POST.get('domestic_vendor_id') == "":
        return Response({"success":False, "message": "Domestic Vendors Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_vendor_id = request.POST.get('domestic_vendor_id')
    if Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Domestic vendor Id" }, status=status.HTTP_401_UNAUTHORIZED)
    pt = Product.objects.filter(domestic_vendor_id=domestic_vendor_id,status=1)
    if pt:
        serializer = ProductSerializer(pt,many=True)
        return Response({"success":True, "message": "Product List","product":serializer.data }, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Product Found" }, status=status.HTTP_401_UNAUTHORIZED)


@api_view(['POST'])
def delete_product(request):
    if request.POST.get('product_id') == "":
        return Response({"success":False, "message": "Product Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    product_id = request.POST.get('product_id')
    if Product.objects.filter(product_id=product_id,status=1).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Product Id" }, status=status.HTTP_401_UNAUTHORIZED)
    Product.objects.filter(product_id=product_id,status=1).first().delete()
    return Response({"success":True, "message": "Product Delete successfully"}, status=status.HTTP_200_OK)



@api_view(['POST'])
def delete_buyers_address(request):
    if request.POST.get('buyers_address_id') == "":
        return Response({"success":False, "message": "Buyers Address Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    buyers_address_id = request.POST.get('buyers_address_id')
    if Buyers_adress.objects.filter(buyers_address_id=buyers_address_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Buyers Address Id" }, status=status.HTTP_401_UNAUTHORIZED)
    Buyers_adress.objects.filter(buyers_address_id=buyers_address_id).first().delete()
    return Response({"success":True, "message": "Address Delete successfully"}, status=status.HTTP_200_OK)


@api_view(['POST'])
def delete_product_image(request):
    if request.POST.get('product_image_id') == "":
        return Response({"success":False, "message": "Product Image Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    product_image_id = request.POST.get('product_image_id')
    if ProductImage.objects.filter(product_image_id=product_image_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Product Image Id" }, status=status.HTTP_401_UNAUTHORIZED)
    ProductImage.objects.filter(product_image_id=product_image_id).first().delete()
    return Response({"success":True, "message": "Product Image Delete successfully"}, status=status.HTTP_200_OK)

@api_view(['POST'])
def active_deactive_product(request):
    if request.POST.get('product_id') == "":
        return Response({"success":False, "message": "Product Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    product_id = request.POST.get('product_id')
    if Product.objects.filter(product_id=product_id,status=1).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Product Id" }, status=status.HTTP_401_UNAUTHORIZED)
    pt = Product.objects.filter(product_id=product_id).first()
    if pt.status == 1:
        print("Helo")
        pt.status = 0
        pt.save()
        lat = "Deactive"
        return Response({"success":True, "message": "Status change sucessfully.","status":lat}, status=status.HTTP_200_OK)
    else:
        print("efgfgfs")
        pt.status = 1
        pt.save()
        lat = "Active"
        return Response({"success":True, "message": "Status change sucessfully.","status":lat}, status=status.HTTP_200_OK)


# View to retrieve a list of orders associated with a domestic vendor
# @api_view(['POST'])
# def vendor_order_request(request):
#     if request.POST.get('domestic_vendor_id') == "":
#         return Response({"success": False, "message": "Domestic Vendor Id is required" }, status=status.HTTP_400_BAD_REQUEST) 

#     domestic_vendor_id = request.POST.get('domestic_vendor_id') 

#     domestic_vendor = Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id).first()

#     if domestic_vendor is None:
#         return Response({"success": False, "message": "Please Enter Valid Domestic Vendor Id" }, status=status.HTTP_401_UNAUTHORIZED)

#     status_filter = request.POST.get('status', 'all')  # Default to 'all' if 'status' is not provided

#     order_query = Order.objects.filter(domestic_vendor_id=domestic_vendor_id, admin_approve=1)

#     if status_filter == '0':
#         order_query = order_query.filter(status=0)
#     elif status_filter == '1':
#         order_query = order_query.filter(status=1)

#     orders = order_query.all()

#     # Filter orders with status 1 (accepted) or status 0 (rejected) if needed
#     filtered_orders = [order for order in orders if order.status != 1 and order.status != 0]

#     if filtered_orders:
#         serializer = DomesticOrderSerializer(filtered_orders, many=True)
#         return Response({"success": True, "message": "Order Listing.", "data": serializer.data}, status=status.HTTP_200_OK)
#     else:
#         return Response({"success": False, "message": "No Orders found" }, status=status.HTTP_404_NOT_FOUND)

# View to activate an order associated with a domestic vendor
@api_view(['POST'])
def active_product_vendor(request):
    if not request.POST.get('domestic_vendor_id'):
        return Response({'success': False, 'message': 'Domestic Vendor Id Is Required'}, status=status.HTTP_400_BAD_REQUEST)
    
    if not request.POST.get('order_id'):
        return Response({'success': False, 'message': 'Order Id Is Required'}, status=status.HTTP_400_BAD_REQUEST)
    
    domestic_vendor_id = request.POST.get('domestic_vendor_id')
    order_id = request.POST.get('order_id')
    
    try:
        order = Order.objects.get(order_id=order_id, domestic_vendor_id=domestic_vendor_id)
    except Order.DoesNotExist:
        return Response({'success': False, 'message': 'Order not found for the given vendor'}, status=status.HTTP_400_BAD_REQUEST)
    
    if order.status == 1:
        return Response({'success': False, 'message': 'Order is already activated'}, status=status.HTTP_400_BAD_REQUEST)
    else:
        order.status = 1
        order.save()
        return Response({'success': True, 'message': 'Order activated successfully', 'status': order.status}, status=status.HTTP_200_OK)

# View to deactivate an order associated with a domestic vendor
@api_view(['POST'])
def deactive_product_vendor(request):
    if not request.POST.get('domestic_vendor_id'):
        return Response({'success': False, 'message': 'Domestic Vendor Id Is Required'}, status=status.HTTP_400_BAD_REQUEST)
    
    if not request.POST.get('order_id'):
        return Response({'success': False, 'message': 'Order Id Is Required'}, status=status.HTTP_400_BAD_REQUEST)
    
    domestic_vendor_id = request.POST.get('domestic_vendor_id')
    order_id = request.POST.get('order_id')
    
    try:
        order = Order.objects.get(order_id=order_id, domestic_vendor_id=domestic_vendor_id)
    except Order.DoesNotExist:
        return Response({'success': False, 'message': 'Order not found for the given vendor'}, status=status.HTTP_400_BAD_REQUEST)
    
    if order.status == 0:
        return Response({'success': False, 'message': 'Order is already deactivated'}, status=status.HTTP_400_BAD_REQUEST)
    else:
        order.status = 0
        order.save()
        return Response({'success': True, 'message': 'Order deactivated successfully'}, status=status.HTTP_200_OK)

from rest_framework import generics
from .models import Product
from .serializers import ProductSerializer

# class FeaturedProductList(generics.ListAPIView):
#     serializer_class = ProductSerializer
    
#     def get_queryset(self):
#         # Retrieve and return a queryset of featured products
#         return Response({'sucess':True,'message':'Featured Product List','data':Product.objects.filter(is_featured=True),'status':status.HTTP_200_OK},status=status.HTTP_200_OK)

# @api_view(['POST'])
# def FeaturedProductList(request):
#     # product_id = request.POST.get('product_id')
#     if request.POST.get('product_id') == "":
#         return Response({"success":False, "message": "Product Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     product_id = request.POST.get('product_id')
#     if Product.objects.filter(product_id=product_id).first() == None:
#         return Response({"success":False, "message": "Please Enter Valid Product Id" }, status=status.HTTP_401_UNAUTHORIZED)
#     domestic_buyers_id = request.POST.get('domestic_buyers_id')
#     if request.POST.get('domestic_buyers_id') == "":
#         return Response({"success":False, "message": "Product Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     domestic_buyers_id = request.POST.get('domestic_buyers_id')
#     if LikeProduct.objects.filter(domestic_buyers_id=domestic_buyers_id).first() == None:
#         return Response({"success":False, "message": "Please Enter Valid domestic buyer Id" }, status=status.HTTP_401_UNAUTHORIZED)
#     pt1 = Product.objects.filter(is_featured=True)
#     if pt1:
#         if LikeProduct.objects.filter( product_id=product_id,domestic_buyers_id=domestic_buyers_id):
#             like = 1
#         else:
#             like = 0
#         serializer = ProductSerializer(pt1, many=True)
#         x = serializer.data
#         for item in x:
#             item['like'] = like
#         return Response({"success": True, "message": "Featured Product List", "product": x, 'status': status.HTTP_200_OK}, status=status.HTTP_200_OK)
#     else:
#         return Response({"success": False, "message": "No product found", 'status': status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)
@api_view(['GET'])
def FeaturedProductList(request):
    pt1 = Product.objects.filter(is_featured=True)
    if pt1:
        serializer = ProductSerializer(pt1, many=True)
        x = serializer.data

        for item in x:
            product_id = item['product_id']
            # domestic_buyers_id=item['domestic_buyers_id']
            like_product = LikeProduct.objects.filter(product_id=product_id)
            item['like'] = 1 if like_product else 0

        return Response({"success": True, "message": "Featured Product List", "product": x, 'status': status.HTTP_200_OK}, status=status.HTTP_200_OK)
    else:
        return Response({"success": False, "message": "No product found", 'status': status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)
@api_view(['GET'])
def sort_product_data(request):
    data=Product.objects.all().order_by('-product_id')
    if data:
        serializer=ProductSerializer(data,many=True)
        return Response({"success": True, "message": "Featured Product List", "product": serializer.data, 'status': status.HTTP_200_OK}, status=status.HTTP_200_OK)
    else:
        return Response({"success": False, "message": "No product found", 'status': status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)
from django.db.models import Q
# @api_view(['POST'])
# def filter_product(request):
#     pt=Product.objects.filter(Q(cost__icontains=request.POST.get('cost')) | Q(product_add_by__icontains=request.POST.get('product_add_by')))
#     if data:
#         serializer=ProductSerializer(pt,many=True)
#         return Response({"success": True, "message": "Featured Product List", "product": serializer.data, 'status': status.HTTP_200_OK}, status=status.HTTP_200_OK)
#     else:
#         return Response({"success": False, "message": "No product found", 'status': status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)


from django.db.models import Q

@api_view(['POST'])
def filter_product(request):
    # Get the values for cost, product_add_by, and product_name from the request data
    cost = request.data.get('cost')
    product_add_by = request.data.get('product_add_by')

    # Initialize the queryset
    queryset = Product.objects.all()

    # Apply filters based on the provided parameters
    if cost:
        # Filter products where the cost is equal to the specified value
        queryset = queryset.filter(cost=cost)
    if product_add_by:
        # Filter products where the product_add_by contains the specified value
        queryset = queryset.filter(product_add_by__icontains=product_add_by)
   

    # Serialize the filtered products
    serializer = ProductSerializer(queryset, many=True)
    x = serializer.data

    # Check if each product has been liked by any user
    for item in x:
        product_id = item['product_id']
        like_product = LikeProduct.objects.filter(product_id=product_id)
        item['like'] = 1 if like_product.exists() else 0

    # Check if any products match the filters
    if x:
        return Response({
            "success": True,
            "message": "Product List",
            "product": x,
        }, status=status.HTTP_200_OK)
    else:
        return Response({
            "success": False,
            "message": "No product found",
        }, status=status.HTTP_400_BAD_REQUEST)





# @api_view(['POST'])
# def local_product_list(request)
@api_view(['POST'])
def product_name_search(request):
    if request.POST.get('search') == "":
        return Response({"success":False, "message": "Search is required" }, status=status.HTTP_400_BAD_REQUEST) 
    search = request.POST.get('search') 
    pt1 = Product.objects.filter(product_name__icontains=search,status=1)
    if pt1:
        serializer=ProductSerializer(pt1,many=True)
        return Response({"success":True, "message": "proudct name detail.","product":serializer.data}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No product found" }, status=status.HTTP_401_UNAUTHORIZED)


@api_view(['POST'])
def search_product(request):
    if request.POST.get('search') == "":
        return Response({"success":False, "message": "Search is required" }, status=status.HTTP_400_BAD_REQUEST) 
    search = request.POST.get('search') 
    pt1 = Product.objects.filter(product_name__icontains=search,status=1)
    ct = Category.objects.filter(category_name__icontains=search)
    if ct:
        for i in ct:
            pt2 = Product.objects.filter(category_id=i.category_id,status=1)
            pt1 = pt1.union(pt1,pt2)
    if pt1:
        serializer = ProductSerializer(pt1,many=True)
        return Response({"success":True, "message": "Status change sucessfully.","product":serializer.data}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No product found" }, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['POST'])
def domestic_product_detail(request):
    if request.POST.get('product_id') == "":
        return Response({"success":False, "message": "Product Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    product_id = request.POST.get('product_id')
    if Product.objects.filter(product_id=product_id,status=1).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Product Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('domestic_buyers_id') == "":
        return Response({"success":False, "message": "Domestic Buyer Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_buyers_id = request.POST.get('domestic_buyers_id')
    if Order.objects.filter(domestic_buyers_id=domestic_buyers_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Domestic Buyer Id" }, status=status.HTTP_401_UNAUTHORIZED)
    pt = Product.objects.filter(product_id=product_id).first()
    serializer = ProductSerializer(pt)
    if LikeProduct.objects.filter(product_id=product_id,domestic_buyers_id=domestic_buyers_id):
        like = 1
    else:
        like = 0
    x = serializer.data
    if pt.expoters_id:
        store_name = pt.expoters_id.store_name
    elif pt.domestic_vendor_id:
        store_name = pt.domestic_vendor_id.store_name
    else:
        store_name = ""
    x.update({"store_name":store_name,"like":like})
    return Response({"success":True, "message": "Product Detail.","product":x}, status=status.HTTP_200_OK)

@api_view(['POST'])
def product_detail(request):
    if request.POST.get('product_id') == "":
        return Response({"success":False, "message": "Product Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    product_id = request.POST.get('product_id')
    if Product.objects.filter(product_id=product_id,status=1).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Product Id" }, status=status.HTTP_401_UNAUTHORIZED)
    pt = Product.objects.filter(product_id=product_id).first()
    serializer = ProductSerializer(pt)
    x = serializer.data
    if pt.expoters_id:
        store_name = pt.expoters_id.store_name
    elif pt.domestic_vendor_id:
        store_name = pt.domestic_vendor_id.store_name
    else:
        store_name = ""
    x.update({"store_name":store_name})
    return Response({"success":True, "message": "Product Detail.","product":x}, status=status.HTTP_200_OK)

@api_view(['Get'])
def domestic_vendor_list(request):
    dvt = Domestic_vendors.objects.all()
    lst = []
    for i in dvt:
        if Product.objects.filter(domestic_vendor_id=i.domestic_vendor_id,status=1):
            lst.append(i)
    if lst:
        serializer = Domestic_vendorsSerializer(lst,many=True)
        return Response({"success":True, "message": "Domestic Vendor List","vendor":serializer.data }, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Vendor Found" }, status=status.HTTP_401_UNAUTHORIZED)



@api_view(['POST'])
def expoters_list(request):
    if request.POST.get('role') == "":
        role = "expoters" 
    else:
        role = request.POST.get('role')
    lst = []
    if role == "expoters":
        exp = Expoters.objects.all()
        for i in exp:
            if Product.objects.filter(expoters_id=i.expoters_id,status=1):
                lst.append(i)
        if lst:
            serializer = ExpotersSerializer(lst, many=True)
            return Response({"success":True, "message": "Expoter List","supplier":serializer.data }, status=status.HTTP_200_OK)
        else:
            return Response({"success":False, "message": "No Expoter Found" }, status=status.HTTP_401_UNAUTHORIZED)       
    elif role == "vendor":
        dvt = Domestic_vendors.objects.all()
        lst = []
        for i in dvt:
            if Product.objects.filter(domestic_vendor_id=i.domestic_vendor_id,status=1):
                lst.append(i)
        if lst:
            serializer = Domestic_vendorsSerializer(lst,many=True)
            return Response({"success":True, "message": "Domestic Vendor List","vendor":serializer.data }, status=status.HTTP_200_OK)
        else:
            return Response({"success":False, "message": "No Vendor Found" }, status=status.HTTP_401_UNAUTHORIZED)
    else:
        return Response({"success":False, "message": "No Vendor Found" }, status=status.HTTP_401_UNAUTHORIZED)



@api_view(['POST'])
def domestic_vendor_profile(request):
    if request.POST.get('domestic_vendor_id') == "":
        return Response({"success":False, "message": "Domestic Vendors Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_vendor_id = request.POST.get('domestic_vendor_id')
    if Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Domestic vendor Id" }, status=status.HTTP_401_UNAUTHORIZED)
    dvt = Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id).first()
    serializer = DomesticVendorProfileSerializer(dvt)
    return Response({"success":True, "message": "Domestic Vendor Profile","domestic_profile":serializer.data }, status=status.HTTP_200_OK)


@api_view(['POST'])
def product_by_category(request):
    if request.POST.get('category_id') == "":
        return Response({"success":False, "message": "Category Id is required" }, status=status.HTTP_400_BAD_REQUEST)
    category_id = request.POST.get('category_id')
    if Category.objects.filter(category_id=category_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Category Id" }, status=status.HTTP_401_UNAUTHORIZED)
    category = Category.objects.filter(category_id=category_id).first()
    product_list = Product.objects.filter(category_id=category_id,status=1,product_add_by="Domestic")
    if product_list:
        serializer = ProductSerializer(product_list,many=True)
        return Response({"success":True, "message": "Product List","product":serializer.data }, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Product Found" }, status=status.HTTP_401_UNAUTHORIZED)


@api_view(['POST'])
def impoters_order(request):
    def order_id_gen():
        res = ''.join(random.choices(string.digits, k=5))
        return res
    order_gen = order_id_gen()
    if Order.objects.filter(order_gen=order_gen):
        order_gen = order_id_gen()
    if request.POST.get('product_id') == "":
        return Response({"success":False, "message": "Product Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    product_id = request.POST.get('product_id')
    if Product.objects.filter(product_id=product_id,status=1).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Product Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('importers_id') == "":
        return Response({"success":False, "message": "Impoters Id is required" }, status=status.HTTP_400_BAD_REQUEST)
    importers_id = request.POST.get('importers_id')
    if Impoters.objects.filter(importers_id=importers_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Impoters Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('quantity') == "":
        return Response({"success":False, "message": "Quantity is required" }, status=status.HTTP_400_BAD_REQUEST) 
    quantity = request.POST.get('quantity')  
    if request.FILES.get('letter_of_intent') == "":
        return Response({"success":False, "message": "Letter of Intent is required" }, status=status.HTTP_400_BAD_REQUEST) 
    letter_of_intent = request.FILES.get('letter_of_intent') 
    pt = Product.objects.filter(product_id=product_id,status=1).first()
    if request.POST.get('importers_id'):
        if pt.expoters_id:
            expoters_id = pt.expoters_id.expoters_id
            ot = Order.objects.create(order_gen=order_gen,product_id_id=product_id,importers_id_id=importers_id,quantity=quantity,letter_of_intent=letter_of_intent,status=1,admin_approve=1,expoters_id_id=expoters_id)
        elif pt.domestic_vendor_id:
            domestic_vendor_id = pt.domestic_vendor_id.domestic_vendor_id
            ot = Order.objects.create(order_gen=order_gen,product_id_id=product_id,importers_id_id=importers_id,quantity=quantity,letter_of_intent=letter_of_intent,status=1,admin_approve=1,domestic_vendor_id_id=domestic_vendor_id)
        serializer = DomesticOrderSerializer(ot)
        return Response({"success":True, "message":"Order Created Successfully.","order_detail":serializer.data},status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Importers Id is required" }, status=status.HTTP_400_BAD_REQUEST)
    


@api_view(['Get'])
def elearning(request):
    elearning_all = Elearning.objects.all()
    lst = []
    if elearning_all:
        for i in elearning_all:
            elearning_id = i.elearning_id
            count = Ecourses.objects.filter(elearning_id = elearning_id).count()
            serializer = ElearningSerializer(i)
            x = serializer.data
            x['count'] = count
            lst.append(x)
        return Response({"success":True, "message": "Elearning Data is here", "data":lst}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Elearning Data is not available"}, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
def ecourses(request):
    if request.POST.get('elearning_id') == "":
        return Response({"success":False, "message": "Elearning Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    elearning_id = request.POST.get('elearning_id')
    if Elearning.objects.filter(elearning_id=elearning_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Elearning Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('expoters_id') == "":
        return Response({"success":False, "message": "Expoters Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    expoters_id = request.POST.get('expoters_id')
    if Expoters.objects.filter(expoters_id=expoters_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Expoters Id" }, status=status.HTTP_401_UNAUTHORIZED)
    ecourse = Ecourses.objects.filter(elearning_id=elearning_id)
    lst = []
    if ecourse:
        for i in ecourse:
            serializer = EcoursesSerializer(i)
            x = serializer.data
            ecourses_id = i.ecourses_id
            if LikeEcourse.objects.filter(ecourses_id=ecourses_id,expoters_id=expoters_id):
                x.update({"like_status":True})
            else:
                x.update({"like_status":False})
            lst.append(x)
        return Response({"success":True, "message": "Ecourses Data is here", "data":lst}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Ecourses Data is not available at this id"}, status=status.HTTP_400_BAD_REQUEST)
    

# @api_view(['POST'])
# def ecourses_detail(request):
#     if request.POST.get('ecourses_id') == "":
#         return Response({"success":False, "message": "Ecourses Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     ecourses_id = request.POST.get('ecourses_id')
#     if Ecourses.objects.filter(ecourses_id=ecourses_id).first() == None:
#         return Response({"success":False, "message": "Please Enter Valid Ecourses Id" }, status=status.HTTP_401_UNAUTHORIZED)
#     ecourse = Ecourses.objects.filter(ecourses_id=ecourses_id).values().first()
#     if ecourse:
#         # serializer = EcoursesSerializer(ecourse)
#         # x = serializer.data
#         # video = x['video']
#         # video = "http://18.117.154.229"+video
#         # clip = VideoFileClip(video)
#         # dur = clip.duration
#         # elearning_id = ecourse.elearning_id.elearning_id
#         # postion = Ecourses.objects.filter(elearning_id=elearning_id)
#         # cou = (list(postion).index(ecourse)) + 1
#         # x.update({"postion":cou,"duration":dur})
#         return Response({"success":True, "message": "Ecourses Data is here", "data":ecourse}, status=status.HTTP_200_OK)
#     else:
#         return Response({"success":False, "message": "Ecourses Data is not available at this id"}, status=status.HTTP_400_BAD_REQUEST)
    
import os
from moviepy.editor import VideoFileClip  # Make sure you import VideoFileClip from moviepy.editor
from moviepy.video.io.ffmpeg_tools import ffmpeg_extract_subclip
import os
import requests  # Import the requests library to download the video
from moviepy.editor import VideoFileClip
from moviepy.video.io.ffmpeg_tools import ffmpeg_extract_subclip
from moviepy.editor import VideoFileClip

class ecourses_detail(generics.GenericAPIView):
    def post(self, request, *args, **kwargs):
        ecourses_id = self.request.POST.get('ecourses_id')
        queryset = Ecourses.objects.filter(ecourses_id=ecourses_id).first()
        
        if queryset:
            serializer = EcoursesSerializer(queryset)
            x = serializer.data
            video = x['video']
            print(video,'video')
            video_url = "http://18.222.211.83:8000"+video  # Full URL
            
            try:
                clip = VideoFileClip(video_url)
                dur = clip.duration
            except Exception as e:
                return Response({"success": False, "message": f"Error loading video: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            elearning_id = queryset.elearning_id.elearning_id
            postion = Ecourses.objects.filter(elearning_id=elearning_id)
            cou = (list(postion).index(queryset)) + 1
            x.update({"postion": cou, "duration": dur})
            return Response({"success": True, "message": "Intent Letter List", 'data': x}, status=status.HTTP_200_OK)
        else:
            return Response({"success": False, "message": "Intent Letter List Not Found"}, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
def like_courses(request):
    if request.POST.get('ecourses_id') == "":
        return Response({"success":False, "message": "Ecourses Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    ecourses_id = request.POST.get('ecourses_id')
    if Ecourses.objects.filter(ecourses_id=ecourses_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Ecourses Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('expoters_id') == "":
        return Response({"success":False, "message": "Expoters Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    expoters_id = request.POST.get('expoters_id')
    if Expoters.objects.filter(expoters_id=expoters_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Expoters Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if LikeEcourse.objects.filter(ecourses_id=ecourses_id,expoters_id=expoters_id):
        LikeEcourse.objects.filter(ecourses_id=ecourses_id,expoters_id=expoters_id).delete()
        return Response({"success":True, "message": "Course Unlike Successfully"}, status=status.HTTP_200_OK)
    else:
        LikeEcourse.objects.create(ecourses_id_id=ecourses_id,expoters_id_id=expoters_id)
        return Response({"success":True, "message": "Course Like Successfully"}, status=status.HTTP_200_OK)
    

@api_view(['POST'])
def expoter_qotation(request):
    if request.POST.get('expoters_id') == "":
        return Response({"success":False, "message": "Expoters Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    expoters_id = request.POST.get('expoters_id')
    if Expoters.objects.filter(expoters_id=expoters_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Expoters Id" }, status=status.HTTP_401_UNAUTHORIZED)
    order = Order.objects.filter(admin_approve=1,order_status=0,expoters_id=expoters_id)
    if order:
        serializer = ExporterOrderSerializer(order,many=True)
        return Response({"success":True, "message": "Expoter Order Data is here", "data":serializer.data}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Expoter Order Data is not available at this id"}, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
def order_status(request):
    if request.POST.get('order_id') == "":
        return Response({"success":False, "message": "Order Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    order_id = request.POST.get('order_id')
    if Order.objects.filter(order_id=order_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Order Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('orderStatus') == "":
        return Response({"success":False, "message": "Order Status is required" }, status=status.HTTP_400_BAD_REQUEST) 
    orderStatus = int(request.POST.get('orderStatus'))
    order = Order.objects.filter(order_id=order_id).first()
    order.order_status = orderStatus
    if orderStatus == 1:
        order.date1 = date.today()
    if orderStatus == 2:
        order.date1 = date.today()
    if orderStatus == 3:
        order.date1 = date.today()
    if orderStatus == 4:
        order.date1 = date.today()
    if orderStatus == 5:
        order.complete_order = 1
        order.date1 = date.today()
    order.save()
    return Response({"success":True, "message": "Order status change successfully"}, status=status.HTTP_200_OK)


@api_view(['POST'])
def expoter_accept_decline(request):
    if request.POST.get('order_id') == "":
        return Response({"success":False, "message": "Order Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    order_id = request.POST.get('order_id')
    if request.POST.get('orderStatus') == "":
        return Response({"success":False, "message": "Order Status is required" }, status=status.HTTP_400_BAD_REQUEST) 
    orderStatus = request.POST.get('orderStatus')
    if Order.objects.filter(order_id=order_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Order Id" }, status=status.HTTP_401_UNAUTHORIZED)
    else:
        order = Order.objects.filter(order_id=order_id).first()
        order.order_status = orderStatus
        order.save()
        return Response({"success":True, "message": "Order status change successfully"}, status=status.HTTP_200_OK)




@api_view(['POST'])
def expoter_accepted(request):
    if request.POST.get('expoters_id') == "":
        return Response({"success":False, "message": "Expoters Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    expoters_id = request.POST.get('expoters_id')
    if Expoters.objects.filter(expoters_id=expoters_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Expoters Id" }, status=status.HTTP_401_UNAUTHORIZED)
    order = Order.objects.filter(admin_approve=1,expoters_id=expoters_id,order_status=1) or Order.objects.filter(admin_approve=1,expoters_id=expoters_id,order_status=2)
    if order:
        lst = []
        for i in order:
            quantity = i.quantity
            cost = i.product_id.cost
            total_price = quantity*cost
            serializer = DomesticOrderSerializer(i)
            x = serializer.data
            x.update({"total_price":total_price})
            lst.append(x)
        return Response({"success":True, "message": "Expoter Order Accepted List","order":lst}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Order Found"}, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['POST'])
def expoter_rejected(request):
    if request.POST.get('expoters_id') == "":
        return Response({"success":False, "message": "Expoters Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    expoters_id = request.POST.get('expoters_id')
    if Expoters.objects.filter(expoters_id=expoters_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Expoters Id" }, status=status.HTTP_401_UNAUTHORIZED)
    order = Order.objects.filter(admin_approve=1,expoters_id=expoters_id,order_status=-1)
    if order:
        lst = []
        for i in order:
            quantity = i.quantity
            cost = i.product_id.cost
            total_price = quantity*cost
            serializer = DomesticOrderSerializer(i)
            x = serializer.data
            x.update({"total_price":total_price})
            lst.append(x)
        return Response({"success":True, "message": "Expoter Order Accepted List","order":lst}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Order Found"}, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['POST'])
def order_shipment_status(request):
    if request.POST.get('order_id') == "":
        return Response({"success":False, "message": "Order Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    order_id = request.POST.get('order_id')
    if Order.objects.filter(order_id=order_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Order Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('shipment') == "":
        return Response({"success":False, "message": "Shipment is required" }, status=status.HTTP_400_BAD_REQUEST) 
    shipment = request.POST.get('shipment')
    order = Order.objects.filter(order_id=order_id).first()
    order.shipment = shipment
    order.save()
    return Response({"success":True, "message": "Order status change successfully"}, status=status.HTTP_200_OK)


@api_view(['POST'])
def expoter_order_history(request):
    if request.POST.get('expoters_id') == "":
        return Response({"success":False, "message": "Expoters Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    expoters_id = request.POST.get('expoters_id')
    if Expoters.objects.filter(expoters_id=expoters_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Expoters Id" }, status=status.HTTP_401_UNAUTHORIZED)
    order = Order.objects.filter(admin_approve=1,expoters_id=expoters_id,order_status=3)
    if order:
        lst = []
        for i in order:
            quantity = i.quantity
            cost = i.product_id.cost
            total_price = quantity*cost
            serializer = DomesticOrderSerializer(i)
            x = serializer.data
            x.update({"total_price":total_price})
            lst.append(x)
        return Response({"success":True, "message": "Expoter Order Accepted List","order":lst}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Order Found"}, status=status.HTTP_401_UNAUTHORIZED)


@api_view(['POST'])
def switch_role(request):
    if request.POST.get('current_role') == "":
        return Response({"success":False, "message": "Current Role is required" }, status=status.HTTP_400_BAD_REQUEST)
    current_role = request.POST.get('current_role')
    if request.POST.get('role') == "":
        return Response({"success":False, "message": "Role is required" }, status=status.HTTP_400_BAD_REQUEST)
    role = request.POST.get('role') 
    if current_role == "expoters":
        if request.POST.get('user_id') == "":
            return Response({"success":False, "message": "Expoters Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
        expoters_id = request.POST.get('user_id')
        if Expoters.objects.filter(expoters_id=expoters_id).first() == None:
            return Response({"success":False, "message": "Please Enter Valid Expoters Id" }, status=status.HTTP_401_UNAUTHORIZED)
        if role == "domestic_vendors":
            et = Expoters.objects.filter(expoters_id=expoters_id).first()
            email_id = et.email_id
            phone_no = et.phone_no
            ut = Domestic_vendors.objects.filter(email_id=email_id)
            if ut:
                ut = ut.first()
                serializer = Domestic_vendorsSerializer(ut)
                return Response({"success":True, "message": "Your Domestic vendor profile detail is here","data":serializer.data }, status=status.HTTP_200_OK)   
            first_name = et.first_name
            last_name = et.last_name 
            referral_code = et.referral_code  
            firebase_token = et.firebase_token
            password = et.password
            password = make_password(password)
            Domestic_vendors.objects.create(first_name=first_name,last_name=last_name,role=role,referral_code=referral_code,firebase_token=firebase_token,email_id=email_id,password=password,phone_no=phone_no)
            st = Domestic_vendors.objects.get(email_id=email_id)
            st.password = password
            st.save()
            serializer = Domestic_vendorsSerializer(st)
            return Response({"success":True, "message": "You registered Successfully","data":serializer.data}, status=status.HTTP_200_OK)
        elif role == "domestic_buyers":
            et = Expoters.objects.filter(expoters_id=expoters_id).first()
            email_id = et.email_id
            phone_no = et.phone_no
            ut = Domestic_buyers.objects.filter(email_id=email_id)
            if ut:
                ut = ut.first()
                serializer = Domestic_buyersSerializer(ut)
                return Response({"success":True, "message": "Your Domestic buyer profile detail is here ","data":serializer.data }, status=status.HTTP_200_OK)   
            first_name = et.first_name
            last_name = et.last_name 
            referral_code = et.referral_code  
            firebase_token = et.firebase_token
            password = et.password
            password = make_password(password)
            Domestic_buyers.objects.create(first_name=first_name,last_name=last_name,role=role,referral_code=referral_code,firebase_token=firebase_token,email_id=email_id,password=password,phone_no=phone_no)
            st = Domestic_buyers.objects.get(email_id=email_id)
            st.password = password
            st.save()
            serializer = Domestic_buyersSerializer(st)
            return Response({"success":True, "message": "You registered Successfully","data":serializer.data}, status=status.HTTP_200_OK)
        else:
            return Response({"success":False, "message": "Please Enter Valid Current Role"}, status=status.HTTP_401_UNAUTHORIZED)
    elif current_role == "domestic_vendors":
        if request.POST.get('user_id') == "":
            return Response({"success":False, "message": "Domestic Vendor Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
        domestic_vendor_id = request.POST.get('user_id')
        print(domestic_vendor_id,"domestic_vendor_id")
        if Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id).first() == None:
            return Response({"success":False, "message": "Please Enter Valid Domestic Vendor Id" }, status=status.HTTP_401_UNAUTHORIZED)
        if role == "expoters":
            et = Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id).first()
            email_id = et.email_id
            phone_no = et.phone_no
            ut = Expoters.objects.filter(email_id=email_id)
            if ut:
                ut = ut.first()
                serializer = ExpotersSerializer(ut)
                return Response({"success":True, "message": "Your Expoter profile detail is here","data":serializer.data }, status=status.HTTP_200_OK)   
            first_name = et.first_name
            last_name = et.last_name 
            referral_code = et.referral_code  
            firebase_token = et.firebase_token
            password = et.password
            password = make_password(password)
            Expoters.objects.create(first_name=first_name,last_name=last_name,role=role,referral_code=referral_code,firebase_token=firebase_token,email_id=email_id,password=password,phone_no=phone_no)
            st = Expoters.objects.get(email_id=email_id)
            st.password = password
            st.save()
            serializer = ExpotersSerializer(st)
            return Response({"success":True, "message": "You registered Successfully","data":serializer.data}, status=status.HTTP_200_OK)
        elif role == "domestic_buyers":
            et = Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id).first()
            email_id = et.email_id
            phone_no = et.phone_no
            ut = Domestic_buyers.objects.filter(email_id=email_id)
            if ut:
                ut = ut.first()
                serializer = Domestic_buyersSerializer(ut)
                return Response({"success":True, "message": "Your Domestic buyer profile detail is here ","data":serializer.data }, status=status.HTTP_200_OK)   
            first_name = et.first_name
            last_name = et.last_name 
            referral_code = et.referral_code  
            firebase_token = et.firebase_token
            password = et.password
            password = make_password(password)
            Domestic_buyers.objects.create(first_name=first_name,last_name=last_name,role=role,referral_code=referral_code,firebase_token=firebase_token,email_id=email_id,password=password,phone_no=phone_no)
            st = Domestic_buyers.objects.get(email_id=email_id)
            st.password = password
            st.save()
            serializer = Domestic_buyersSerializer(st)
            return Response({"success":True, "message": "You registered Successfully","data":serializer.data}, status=status.HTTP_200_OK)
        else:
            return Response({"success":False, "message": "Please Enter Valid Current Role"}, status=status.HTTP_401_UNAUTHORIZED)
    elif current_role == "domestic_buyers":
        if request.POST.get('user_id') == "":
            return Response({"success":False, "message": "Domestic Buyers Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
        domestic_buyers_id = request.POST.get('user_id')
        print(domestic_buyers_id,"domestic_buyers_id")
        if Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first() == None:
            return Response({"success":False, "message": "Please Enter Valid Domestic Buyers Id" }, status=status.HTTP_401_UNAUTHORIZED)
        if role == "domestic_vendors":
            et = Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first()
            email_id = et.email_id
            phone_no = et.phone_no
            ut = Domestic_vendors.objects.filter(email_id=email_id)
            if ut:
                ut = ut.first()
                serializer = Domestic_vendorsSerializer(ut)
                return Response({"success":True, "message": "Your Domestic Vendor profile detail is here","data":serializer.data }, status=status.HTTP_200_OK)   
            first_name = et.first_name
            last_name = et.last_name 
            referral_code = et.referral_code  
            firebase_token = et.firebase_token
            password = et.password
            password = make_password(password)
            Domestic_vendors.objects.create(first_name=first_name,last_name=last_name,role=role,referral_code=referral_code,firebase_token=firebase_token,email_id=email_id,password=password,phone_no=phone_no)
            st = Domestic_vendors.objects.get(email_id=email_id)
            st.password = password
            st.save()
            serializer = Domestic_vendorsSerializer(st)
            return Response({"success":True, "message": "You registered Successfully","data":serializer.data}, status=status.HTTP_200_OK)
        elif role == "expoters":
            et = Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first()
            email_id = et.email_id
            phone_no = et.phone_no
            ut = Expoters.objects.filter(email_id=email_id)
            if ut:
                ut = ut.first()
                serializer = ExpotersSerializer(ut)
                return Response({"success":True, "message": "Your Expoter profile detail is here","data":serializer.data }, status=status.HTTP_200_OK)   
            first_name = et.first_name
            last_name = et.last_name 
            referral_code = et.referral_code  
            firebase_token = et.firebase_token
            password = et.password
            password = make_password(password)
            Expoters.objects.create(first_name=first_name,last_name=last_name,role=role,referral_code=referral_code,firebase_token=firebase_token,email_id=email_id,password=password,phone_no=phone_no)
            st = Expoters.objects.get(email_id=email_id)
            st.password = password
            st.save()
            serializer = ExpotersSerializer(st)
            return Response({"success":True, "message": "You registered Successfully","data":serializer.data}, status=status.HTTP_200_OK)
        else:
            return Response({"success":False, "message": "Please Enter Valid Current Role"}, status=status.HTTP_401_UNAUTHORIZED)
    else:
        return Response({"success":False, "message": "Role is invalid" }, status=status.HTTP_401_UNAUTHORIZED)
    
    

@api_view(['POST'])
def fav_course_list(request):
    if request.POST.get('expoters_id') == "":
        return Response({"success":False, "message": "Expoters Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    expoters_id = request.POST.get('expoters_id')
    if Expoters.objects.filter(expoters_id=expoters_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Expoters Id" }, status=status.HTTP_401_UNAUTHORIZED)
    fav = LikeEcourse.objects.filter(expoters_id=expoters_id)
    if fav:
        serializer = LikeEcourseSerializer(fav,many=True)
        return Response({"success":True, "message": "Fav Course List","fav":serializer.data}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Fav Course Found"}, status=status.HTTP_401_UNAUTHORIZED)
    


@api_view(['POST'])
def expoter_product(request):
    if request.POST.get('expoters_id') == "":
        return Response({"success":False, "message": "Expoters Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    expoters_id = request.POST.get('expoters_id')
    if Expoters.objects.filter(expoters_id=expoters_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Expoters Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if Product.objects.filter(expoters_id=expoters_id,status=1):
        pt = Product.objects.filter(expoters_id=expoters_id,status=1)
        serializer = ProductSerializer(pt,many=True)
        return Response({"success":True,"message":"Expoter Product list", "products":serializer.data},status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No product found on this Expoter Id." }, status=status.HTTP_401_UNAUTHORIZED)
    

# @api_view(['POST'])
# def domestic_add_to_product(request):
#     if request.POST.get('domestic_buyers_id') == "":
#         return Response({"success":False, "message": "Domestic Buyers Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     domestic_buyers_id = request.POST.get('domestic_buyers_id')
#     if Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first() == None:
#         return Response({"success":False, "message": "Please Enter Valid Domestic Buyers Id" }, status=status.HTTP_401_UNAUTHORIZED)
#     if request.POST.get('quantity') == "":
#         return Response({"success":False, "message": "Quantiy is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     quantity = int(request.POST.get('quantity'))
#     if request.POST.get('product_id') == "":
#         return Response({"success":False, "message": "Product Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     product_id = request.POST.get('product_id')
#     if Product.objects.filter(product_id=product_id,status=1).first() == None:
#         return Response({"success":False, "message": "Please Enter Valid Product Id" }, status=status.HTTP_401_UNAUTHORIZED)
#     product = Product.objects.filter(product_id=product_id,status=1).first()
#     if quantity <= product.variant_quantity:
#         if Cart.objects.filter(product_id=product_id,domestic_buyers_id=domestic_buyers_id):
#             ct = Cart.objects.filter(product_id=product_id,domestic_buyers_id=domestic_buyers_id).first()
#             if quantity + ct.quantity <= product.variant_quantity:
#                 ct.price = product.cost * (quantity + ct.quantity)
#                 ct.quantity = quantity+ct.quantity
#                 ct.save()
#                 serializer = CartSerializer(ct)
#                 return Response({"success":True, "message": "Prodcut is added in cart","data":serializer.data}, status=status.HTTP_200_OK)
#             else:
#                 qun = ct.product_id.variant_quantity - ct.quantity
#                 return Response({"success": False, "message": f"You will only add {str(qun)} item."}, status=status.HTTP_401_UNAUTHORIZED)
#         else:
#             price = product.cost * quantity
#             ct = Cart.objects.create(domestic_buyers_id_id=domestic_buyers_id,product_id_id=product_id,price=price,quantity=quantity)
#             serializer = CartSerializer(ct)
#             return Response({"success":True, "message": "Prodcut is added in cart","data":serializer.data}, status=status.HTTP_200_OK)
#     else:
#         qun = product.variant_quantity - quantity
#         return Response({"success":False, "message": f"You will only add {str(qun)} item." }, status=status.HTTP_401_UNAUTHORIZED)
        
    
from rest_framework.decorators import api_view
from rest_framework import status
from rest_framework.response import Response

@api_view(['POST'])
def domestic_add_to_product(request):
    domestic_buyers_id = request.POST.get('domestic_buyers_id')
    quantity = request.POST.get('quantity')
    product_id = request.POST.get('product_id')

    # Check if required fields are provided
    if not domestic_buyers_id:
        return Response({"success": False, "message": "Domestic Buyers Id is required" }, status=status.HTTP_400_BAD_REQUEST) 

    if not quantity:
        return Response({"success": False, "message": "Quantity is required" }, status=status.HTTP_400_BAD_REQUEST) 

    if not product_id:
        return Response({"success": False, "message": "Product Id is required" }, status=status.HTTP_400_BAD_REQUEST) 

    # Check if domestic buyer and product exist
    domestic_buyer = Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first()
    if not domestic_buyer:
        return Response({"success": False, "message": "Invalid Domestic Buyers Id" }, status=status.HTTP_401_UNAUTHORIZED)

    product = Product.objects.filter(product_id=product_id, status=1).first()
    if not product:
        return Response({"success": False, "message": "Invalid Product Id" }, status=status.HTTP_401_UNAUTHORIZED)

    quantity = int(quantity)

    # Check if quantity is valid
    if product.variant_quantity <= 0:
        return Response({"success": False, "message": "Product is out of stock" }, status=status.HTTP_400_BAD_REQUEST)

    if quantity > product.variant_quantity:
        return Response({"success": False, "message": "Quantity exceeds available stock" }, status=status.HTTP_400_BAD_REQUEST)


    # Check if the item is already in the cart
    cart_item = Cart.objects.filter(product_id=product_id, domestic_buyers_id=domestic_buyers_id).first()
    if cart_item:
        new_quantity = cart_item.quantity + quantity
        if new_quantity > product.variant_quantity:
            # return Response({"success": False, "message": f" You can buy or add to cart {product.variant_quantity - cart_item.quantity} or less than {product.variant_quantity - cart_item.quantity} quantity items " }, status=status.HTTP_400_BAD_REQUEST)
             return Response({"success": False, "message": "product is out of stock" }, status=status.HTTP_400_BAD_REQUEST)

        cart_item.quantity = new_quantity
        cart_item.price = product.cost * new_quantity
        cart_item.save()
        serializer = CartSerializer(cart_item)
        return Response({"success": True, "message": "Product is added to the cart", "data": serializer.data}, status=status.HTTP_200_OK)
    else:
        price = product.cost * quantity
        cart_item = Cart.objects.create(domestic_buyers_id_id=domestic_buyers_id, product_id_id=product_id, price=price, quantity=quantity)
        serializer = CartSerializer(cart_item)
        return Response({"success": True, "message": "Product is added to the cart", "data": serializer.data}, status=status.HTTP_200_OK)


@api_view(['Get'])
def learn_more(request):
    lm = Learn_more.objects.filter(status=1)
    if lm:
        serializers = LearnmoreSerializer(lm, many=True)
        return Response({"success":True, "message": "Here is your Learn More list","data":serializers.data}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Learn More Found" }, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['POST'])
def domestic_product_list(request):
    if request.POST.get('category_id') == "":
        return Response({"success":False, "message": "Category Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    category_id = request.POST.get('category_id')
    if Category.objects.filter(category_id=category_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Category Id" }, status=status.HTTP_401_UNAUTHORIZED)
    pt = Product.objects.filter(category_id=category_id,status=1)
    if pt:
        lst = []
        for i in pt:
            if i.domestic_vendor_id:
                dict = {"product_id":i.product_id,"product_name":i.product_name}
                lst.append(dict)
        return Response({"success":True, "message": "Here is your Product list","product_list":lst}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Product Found" }, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['POST'])
def domestic_search_product(request):
    if request.POST.get('search') == "":
        return Response({"success":False, "message": "Search is required" }, status=status.HTTP_400_BAD_REQUEST) 
    search = request.POST.get('search') 
    if request.POST.get('domestic_buyers_id') == "":
        return Response({"success":False, "message": "domestic_buyers_id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_buyers_id = request.POST.get('domestic_buyers_id') 
    pt1 = Product.objects.filter(product_name__icontains=search,status=1)
    ct = Category.objects.filter(category_name__icontains=search)
    if ct:
        for i in ct:
            pt2 = Product.objects.filter(category_id=i.category_id,status=1)
            pt1 = pt1.union(pt1,pt2)
    lst = []
    if pt1:
        for i in pt1:
            if i.domestic_vendor_id:
               lst.append(i)
        xyz = []
        print(lst)
        for i in lst:
            product_id = i.product_id
            if LikeProduct.objects.filter(product_id=product_id,domestic_buyers_id=domestic_buyers_id):
                like = 1
            else:
                like = 0
            serializer = ProductSerializer(i)
            x = serializer.data
            x.update({"like":like})
            xyz.append(x)
        return Response({"success":True, "message": "Your search product list is here.","product":xyz}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No product found" }, status=status.HTTP_401_UNAUTHORIZED)


@api_view(['POST'])
def cart_delete(request):
    if request.POST.get('cart_id') == "":
        return Response({"success":False, "message": "Cart Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    cart_id = request.POST.get('cart_id') 
    ct = Cart.objects.filter(cart_id=cart_id)
    if ct:
        ct = Cart.objects.filter(cart_id=cart_id).delete()
        return Response({"success":True, "message": "Item Deleted Successfully"}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Cart Found" }, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['POST'])
def cart_edit(request):
    if request.POST.get('cart_id') == "":
        return Response({"success":False, "message": "Cart Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    cart_id = request.POST.get('cart_id') 
    if request.POST.get('quantity') == "":
        return Response({"success":False, "message": "Quantity is required" }, status=status.HTTP_400_BAD_REQUEST) 
    quantity = int(request.POST.get('quantity') )
    ct = Cart.objects.filter(cart_id=cart_id).first()
    if ct:
        price = ct.product_id.cost
        ct.quantity = quantity
        ct.price = quantity*price
        ct.save()
        return Response({"success":True, "message": "Item Updated Successfully"}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Cart Found" }, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['POST'])
def cart_list(request):
    if request.POST.get('domestic_buyers_id') == "":
        return Response({"success":False, "message": "Domestic Buyers Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_buyers_id = request.POST.get('domestic_buyers_id') 
    if Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Domestic Buyers Id" }, status=status.HTTP_401_UNAUTHORIZED)
    ct = Cart.objects.filter(domestic_buyers_id=domestic_buyers_id)
    count = Cart.objects.filter(domestic_buyers_id=domestic_buyers_id).count()
    if ct:
        sub_total = 0
        lst = []
        for i in ct:
            serializer = CartSerializer(i)
            x = serializer.data
            pi = ProductImage.objects.filter(product_id =i.product_id.product_id).first()
            if pi:
                img = ProductImageSerializer(pi)
                x['product_id'].update({"product_image":img.data['image']})
            else:
                x['product_id'].update({"product_image":""})
            sub_total += i.price
            lst.append(x)
        ship_id = request.POST.get("ship_id")
        if ship_id:
            st = Shipping_type.objects.filter(ship_id=ship_id).first()
        else:
            st = Shipping_type.objects.filter(shipping_title="Standard Delivery").first()
        if st:
            shipping_charge = st.price
        else:
            shipping_charge = 0
        total = shipping_charge + sub_total
        return Response({"success":True, "message": "Cart Listing","cart":lst,"sub_total":sub_total,"shipping_charge":shipping_charge,"total":total,"count":count}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Cart Found" }, status=status.HTTP_401_UNAUTHORIZED)


@api_view(['Get'])
def shipping_types_list(request):
    st = Shipping_type.objects.filter(status=1)
    if st:
        serializer = ShippingSerializer(st, many=True)
        return Response({"success":True, "message": "Shipping Types Listing","data":serializer.data}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Shipping Types Found" }, status=status.HTTP_401_UNAUTHORIZED)



@api_view(['POST'])
def buyers_address_list(request):
    if request.POST.get('domestic_buyers_id') == "":
        return Response({"success":False, "message": "Domestic Buyers Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_buyers_id = request.POST.get('domestic_buyers_id') 
    if Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Domestic Buyers Id" }, status=status.HTTP_401_UNAUTHORIZED)
    at = Buyers_adress.objects.filter(domestic_buyers_id=domestic_buyers_id)
    ship_id = request.POST.get('ship_id') 
    if ship_id:
        if Shipping_type.objects.filter(ship_id=ship_id).first() == None:
            return Response({"success":False, "message": "Please Enter Valid Ship Id" }, status=status.HTTP_401_UNAUTHORIZED)
        ship = Shipping_type.objects.filter(ship_id=ship_id).first()
        day = ship.delivery_day
        today_date = date.today()
        ship_day = today_date + timedelta(days=day)
        if at:
            serializer = BuyersAddressSerializer(at, many=True)
            return Response({"success":True, "message": "Domestic Buyers Address Listing","address":serializer.data,"title":ship.shipping_title,"ship_day":ship_day}, status=status.HTTP_200_OK)
        else:
            return Response({"success":False, "message": "No Address Found" }, status=status.HTTP_401_UNAUTHORIZED)
    else:
        if Shipping_type.objects.filter(shipping_title="Standard Delivery").first() == None:
            return Response({"success":False, "message": "Please Enter Valid Ship Id" }, status=status.HTTP_401_UNAUTHORIZED)
        ship = Shipping_type.objects.filter(shipping_title="Standard Delivery").first()
        day = ship.delivery_day
        today_date = date.today()
        ship_day = today_date + timedelta(days=day)
        if at:
            serializer = BuyersAddressSerializer(at, many=True)
            return Response({"success":True, "message": "Domestic Buyers Address Listing","address":serializer.data,"title":ship.shipping_title,"ship_day":ship_day}, status=status.HTTP_200_OK)
        else:
            return Response({"success":False, "message": "No Address Found" }, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['POST'])
def add_buyers_address(request):
    if request.POST.get('domestic_buyers_id') == "":
        return Response({"success":False, "message": "Domestic Buyers Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_buyers_id = request.POST.get('domestic_buyers_id') 
    if Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Domestic Buyers Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('name') == "":
        return Response({"success":False, "message": "Name is required" }, status=status.HTTP_400_BAD_REQUEST) 
    name = request.POST.get('name')
    if request.POST.get('email_id') == "":
        return Response({"success":False, "message": "Email Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    email_id = request.POST.get('email_id')
    if request.POST.get('phone_no') == "":
        return Response({"success":False, "message": "Phone Number is required" }, status=status.HTTP_400_BAD_REQUEST) 
    phone_no = request.POST.get('phone_no')
    if request.POST.get('address') == "":
        return Response({"success":False, "message": "Address is required" }, status=status.HTTP_400_BAD_REQUEST) 
    address = request.POST.get('address')
    if request.POST.get('zip_code') == "":
        return Response({"success":False, "message": "Zip Code is required" }, status=status.HTTP_400_BAD_REQUEST) 
    zip_code = request.POST.get('zip_code')
    if request.POST.get('city') == "":
        return Response({"success":False, "message": "City is required" }, status=status.HTTP_400_BAD_REQUEST) 
    city = request.POST.get('city')
    if request.POST.get('country') == "":
        return Response({"success":False, "message": "Country is required" }, status=status.HTTP_400_BAD_REQUEST) 
    country = request.POST.get('country')
    if request.POST.get('by_default') == "":
        return Response({"success":False, "message": "By Default is required" }, status=status.HTTP_400_BAD_REQUEST) 
    by_default = request.POST.get('by_default')
    if by_default == "true":
        by_default = 1
        adddd = Buyers_adress.objects.all()
        for i in adddd:
            i.by_default = 0
            i.save()
    else:
        by_default = 0
    at = Buyers_adress.objects.create(domestic_buyers_id_id=domestic_buyers_id,name=name,email_id=email_id,phone_no=phone_no,address=address,zip_code=zip_code,city=city,country=country,by_default=by_default)
    if at:
        serializer = BuyersAddressSerializer(at)
        return Response({"success":True, "message": "Domestic Buyers Address added successfully","address":serializer.data}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Sorry! Address is not added please try again." }, status=status.HTTP_401_UNAUTHORIZED)



@api_view(['POST'])
def update_buyers_address(request):
    if request.POST.get('domestic_buyers_id') == "":
        return Response({"success":False, "message": "Domestic Buyers Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_buyers_id = request.POST.get('domestic_buyers_id') 
    if Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Buyers Address Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('buyers_address_id') == "":
        return Response({"success":False, "message": "Buyers Address Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    buyers_address_id = request.POST.get('buyers_address_id') 
    if Buyers_adress.objects.filter(buyers_address_id=buyers_address_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Domestic Buyers Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('name') == "":
        return Response({"success":False, "message": "Name is required" }, status=status.HTTP_400_BAD_REQUEST) 
    name = request.POST.get('name')
    if request.POST.get('email_id') == "":
        return Response({"success":False, "message": "Email Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    email_id = request.POST.get('email_id')
    if request.POST.get('phone_no') == "":
        return Response({"success":False, "message": "Phone Number is required" }, status=status.HTTP_400_BAD_REQUEST) 
    phone_no = request.POST.get('phone_no')
    if request.POST.get('address') == "":
        return Response({"success":False, "message": "Address is required" }, status=status.HTTP_400_BAD_REQUEST) 
    address = request.POST.get('address')
    if request.POST.get('zip_code') == "":
        return Response({"success":False, "message": "Zip Code is required" }, status=status.HTTP_400_BAD_REQUEST) 
    zip_code = request.POST.get('zip_code')
    if request.POST.get('city') == "":
        return Response({"success":False, "message": "City is required" }, status=status.HTTP_400_BAD_REQUEST) 
    city = request.POST.get('city')
    if request.POST.get('country') == "":
        return Response({"success":False, "message": "Country is required" }, status=status.HTTP_400_BAD_REQUEST) 
    country = request.POST.get('country')
    if request.POST.get('by_default') == "":
        return Response({"success":False, "message": "By Default is required" }, status=status.HTTP_400_BAD_REQUEST) 
    by_default = request.POST.get('by_default')
    if by_default == "true":
        print("sdffd")
        by_default = 1
        adddd = Buyers_adress.objects.all()
        for i in adddd:
            i.by_default = 0
            i.save()
    else:
        by_default = 0
    at = Buyers_adress.objects.filter(domestic_buyers_id=domestic_buyers_id,buyers_address_id=buyers_address_id).first()
    at.name = name
    at.email_id = email_id
    at.phone_no = phone_no
    at.address = address
    at.zip_code = zip_code
    at.city = city
    at.country = country
    at.by_default = by_default
    at.save()
    if at:
        serializer = BuyersAddressSerializer(at)
        return Response({"success":True, "message": "Domestic Buyers Address Updated successfully","address":serializer.data}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "Sorry! Address is not added please try again." }, status=status.HTTP_401_UNAUTHORIZED)


@api_view(['POST'])
def order_summary(request):
    if request.POST.get('domestic_buyers_id') == "":
        return Response({"success":False, "message": "Domestic Buyers Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_buyers_id = request.POST.get('domestic_buyers_id') 
    if Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Domestic Buyers Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('buyers_address_id') == "":
        return Response({"success":False, "message": "Buyers Address Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    buyers_address_id = request.POST.get('buyers_address_id') 
    if Buyers_adress.objects.filter(buyers_address_id=buyers_address_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Buyers Address Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('ship_id') == "":
        return Response({"success":False, "message": "Ship Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    ship_id = request.POST.get('ship_id') 
    if Shipping_type.objects.filter(ship_id=ship_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Ship Id" }, status=status.HTTP_401_UNAUTHORIZED)
    ship = Shipping_type.objects.filter(ship_id=ship_id).first()
    address = Buyers_adress.objects.filter(buyers_address_id=buyers_address_id).first()
    day = ship.delivery_day
    today_date = date.today()
    ship_day = today_date + timedelta(days=day)
    dd = ship_day.strftime("%A, %d %B, %y")
    address_ser = BuyersAddressSerializer(address)
    shipping_charge = ship.price
    ct = Cart.objects.filter(domestic_buyers_id=domestic_buyers_id)
    if ct:
        item_price = 0
        for i in ct:
            item_price += i.price
        total_price = item_price + shipping_charge
        return Response({"success":True, "message": "Order Summery.","address":address_ser.data,"ship_day":dd,"item_price":item_price,"shipping_charge":shipping_charge,"total_price":total_price}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Item found in your cart." }, status=status.HTTP_401_UNAUTHORIZED)


# @api_view(['POST'])
# def create_order(request):
#     if request.POST.get('domestic_buyers_id') == "":
#         return Response({"success":False, "message": "Domestic Buyers Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     domestic_buyers_id = request.POST.get('domestic_buyers_id') 
#     if Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first() == None:
#         return Response({"success":False, "message": "Please Enter Valid Domestic Buyers Id" }, status=status.HTTP_401_UNAUTHORIZED)
#     if request.POST.get('ship_id') == "":
#         return Response({"success":False, "message": "Ship Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     ship_id = request.POST.get('ship_id') 
#     if Shipping_type.objects.filter(ship_id=ship_id).first() == None:
#         return Response({"success":False, "message": "Please Enter Valid Ship Id" }, status=status.HTTP_401_UNAUTHORIZED)
#     st = Shipping_type.objects.filter(ship_id=ship_id).first()
#     ct = Cart.objects.filter(domestic_buyers_id=domestic_buyers_id)
#     if ct:
#         for i in ct:
#             day = st.delivery_day
#             today_date = date.today()
#             ship_day = today_date + timedelta(days=day)
#             def order_id_gen():
#                 res = ''.join(random.choices(string.digits, k=5))
#                 return res
#             order_gen = order_id_gen()
#             if Order.objects.filter(order_gen=order_gen):
#                 order_gen = order_id_gen()
#             product_id = i.product_id.product_id
#             domestic_vendor_id = i.product_id.domestic_vendor_id.domestic_vendor_id
#             quantity = i.quantity
#             ot = Order.objects.create(order_gen=order_gen,product_id_id=product_id,domestic_buyers_id_id=domestic_buyers_id,quantity=quantity,status=1,admin_approve=1,domestic_vendor_id_id=domestic_vendor_id,ship_id_id=ship_id,expected_date=ship_day)
#         ct.delete()
#         return Response({"success":True, "message": "Order is placed successfully."}, status=status.HTTP_200_OK)
#     else:
#         return Response({"success":False, "message": "No Item found in cart" }, status=status.HTTP_401_UNAUTHORIZED)
    
@api_view(['POST'])
def create_order(request):
    domestic_buyers_id = request.POST.get('domestic_buyers_id')
    ship_id = request.POST.get('ship_id')

    if domestic_buyers_id == "":
        return Response({"success": False, "message": "Domestic Buyers Id is required"}, status=status.HTTP_400_BAD_REQUEST)

    if ship_id == "":
        return Response({"success": False, "message": "Ship Id is required"}, status=status.HTTP_400_BAD_REQUEST)

    domestic_buyer = Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first()
    shipping_type = Shipping_type.objects.filter(ship_id=ship_id).first()

    if domestic_buyer is None:
        return Response({"success": False, "message": "Please Enter Valid Domestic Buyers Id"}, status=status.HTTP_401_UNAUTHORIZED)

    if shipping_type is None:
        return Response({"success": False, "message": "Please Enter Valid Ship Id"}, status=status.HTTP_401_UNAUTHORIZED)

    cart_items = Cart.objects.filter(domestic_buyers_id=domestic_buyers_id)

    if not cart_items:
        return Response({"success": False, "message": "No Item found in cart"}, status=status.HTTP_401_UNAUTHORIZED)

    today_date = date.today()
    ship_day = today_date + timedelta(days=shipping_type.delivery_day)

    def order_id_gen():
        res = ''.join(random.choices(string.digits, k=5))
        return res

    for cart_item in cart_items:
        product = cart_item.product_id
        if product is not None and product.domestic_vendor_id is not None:
            order_gen = order_id_gen()
            # Check if the order_gen is already used, and if so, regenerate it
            while Order.objects.filter(order_gen=order_gen).exists():
                order_gen = order_id_gen()

            Order.objects.create(
                order_gen=order_gen,
                product_id_id=product.product_id,
                domestic_buyers_id_id=domestic_buyers_id,
                quantity=cart_item.quantity,
                status=1,
                admin_approve=1,
                domestic_vendor_id_id=product.domestic_vendor_id.domestic_vendor_id,
                ship_id_id=ship_id,
                expected_date=ship_day
            )

    # Clear the cart items
    cart_items.delete()

    return Response({"success": True, "message": "Order is placed successfully."}, status=status.HTTP_200_OK)

# @api_view(['POST'])
# def address_detail(request):
#     if not  request.POST.get('buyers_address_id') == "":
#         return Response({"success":False, "message": "Domestic Buyers Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     buyers_address_id = request.POST.get('buyers_address_id') 
#     buyer=Buyers_adress.objects.filter(buyers_address_id=buyers_address_id)
#     if buyer:
#         serializer=BuyersAddressSerializer(buyer,many=True)
#         x=serializer.data
#         return Response({"success":True, "message": "Buyer Address Listing.","data":x}, status=status.HTTP_200_OK)
#     else:
#         return Response({"success":False, "message": "No Order found" }, status=status.HTTP_400_BAD_REQUEST)
        
# class address_detail(APIView):
#     def post(self,request):
#         if request.POST.get('buyers_address_id') == "":
#             return Response({"success":False, "message": "Buyers Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#         buyers_address_id = request.POST.get('buyers_address_id') 
#         buyer=Buyers_adress.objects.filter(buyers_address_id=buyers_address_id).values()
#         # if buyer:
#             # serializer=BuyersAddressSerializer(buyer,many=True)
#         return Response({"success":True, "message": "Buyer Address Listing.","data":buyer}, status=status.HTTP_200_OK)
#         # else:
#         #     return Response({"success":False, "message": "No Buyer Address Listing found" }, status=status.HTTP_400_BAD_REQUEST)

class address_detail(APIView):
    def post(self, request):
        buyers_address_id = request.POST.get('buyers_address_id')

        if buyers_address_id == "":
            return Response({"success": False, "message": "Buyers Id is required" }, status=status.HTTP_400_BAD_REQUEST)

        buyer = Buyers_adress.objects.filter(buyers_address_id=buyers_address_id).first()

        if buyer:
            serializer=BuyersAddressSerializer(buyer)
            return Response({"success": True, "message": "Buyer Address Listing.", "data": serializer.data}, status=status.HTTP_200_OK)
        else:
            return Response({"success": False, "message": "Buyer Address not found."}, status=status.HTTP_404_NOT_FOUND)

@api_view(['POST'])
def domestic_order_all(request):
    if request.POST.get('domestic_buyers_id') == "":
        return Response({"success":False, "message": "Domestic Buyers Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_buyers_id = request.POST.get('domestic_buyers_id') 
    if Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Domestic Buyers Id" }, status=status.HTTP_401_UNAUTHORIZED)
    order = Order.objects.filter(domestic_buyers_id=domestic_buyers_id)
    if order:
        serializer = DomesticOrderSerializer(order, many=True)
        return Response({"success":True, "message": "Order Listing.","data":serializer.data}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Order found" }, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['POST'])
def domestic_order_ongoing(request):
    if request.POST.get('domestic_buyers_id') == "":
        return Response({"success":False, "message": "Domestic Buyers Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_buyers_id = request.POST.get('domestic_buyers_id') 
    if Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Domestic Buyers Id" }, status=status.HTTP_401_UNAUTHORIZED)
    order = Order.objects.filter(domestic_buyers_id=domestic_buyers_id,complete_order=0)
    if order:
        serializer = DomesticOrderSerializer(order, many=True)
        return Response({"success":True, "message": "Order Listing.","data":serializer.data}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Order found" }, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['POST'])
def domestic_order_history(request):
    if request.POST.get('domestic_buyers_id') == "":
        return Response({"success":False, "message": "Domestic Buyers Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_buyers_id = request.POST.get('domestic_buyers_id') 
    if Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Domestic Buyers Id" }, status=status.HTTP_401_UNAUTHORIZED)
    order = Order.objects.filter(domestic_buyers_id=domestic_buyers_id,complete_order=1)
    if order:
        serializer = DomesticOrderSerializer(order, many=True)
        return Response({"success":True, "message": "Order Listing.","data":serializer.data}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Order found" }, status=status.HTTP_401_UNAUTHORIZED)


@api_view(['POST'])
def add_review(request):
    if request.POST.get('order_id') == "":
        return Response({"success":False, "message": "Order Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    order_id = request.POST.get('order_id')
    if Order.objects.filter(order_id=order_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Order Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('rate') == "":
        return Response({"success":False, "message": "Rate is required" }, status=status.HTTP_400_BAD_REQUEST) 
    rate = int(request.POST.get('rate')) 
    if request.POST.get('comment') == "":
        return Response({"success":False, "message": "Comment is required" }, status=status.HTTP_400_BAD_REQUEST) 
    comment = request.POST.get('comment') 
    rt = Review.objects.create(rate=rate,comment=comment)
    return Response({"success":True, "message": "Rate added successfully."}, status=status.HTTP_200_OK)


@api_view(['POST'])
def buyer_like_product(request):
    if request.POST.get('product_id') == "":
        return Response({"success":False, "message": "Product Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    product_id = request.POST.get('product_id')
    if Product.objects.filter(product_id=product_id,status=1).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Product Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('domestic_buyers_id') == "":
        return Response({"success":False, "message": "Domestic Buyers Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_buyers_id = request.POST.get('domestic_buyers_id')
    if Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Domestic Buyers Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if LikeProduct.objects.filter(product_id=product_id,domestic_buyers_id=domestic_buyers_id):
        LikeProduct.objects.filter(product_id=product_id,domestic_buyers_id=domestic_buyers_id).delete()
        return Response({"success":True, "message": "Product Unlike Successfully"}, status=status.HTTP_200_OK)
    else:
        LikeProduct.objects.create(product_id_id=product_id,domestic_buyers_id_id=domestic_buyers_id)
        return Response({"success":True, "message": "Product Like Successfully"}, status=status.HTTP_200_OK)
    

@api_view(['POST'])
def buyerlike_productlist(request):
    if request.POST.get('domestic_buyers_id') == "":
        return Response({"success":False, "message": "Domestic Buyers Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_buyers_id = request.POST.get('domestic_buyers_id')
    if Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Domestic Buyers Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if LikeProduct.objects.filter(domestic_buyers_id=domestic_buyers_id):
        buy_like = LikeProduct.objects.filter(domestic_buyers_id=domestic_buyers_id)
        lst = []
        for i in buy_like:
            serializer = BuyersProduct_likeSerializer(i)
            x = serializer.data
            product_id = i.product_id.product_id
            product_img = ProductImage.objects.filter(product_id=product_id).first()
            xyz = ProductImageSerializer(product_img)
            x.update({"product_name":i.product_id.product_name,"store_name":i.product_id.domestic_vendor_id.store_name,"image":xyz.data})
            lst.append(x)
        return Response({"success":True, "message": "Like product list","data":lst}, status=status.HTTP_200_OK)
    else:
        return Response({"success":True, "message": "No product is liked by you."}, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['Get'])
def plan_list(request):
    plan = Plans.objects.filter(status=1)
    if plan:
        serializer = PlanSerializer(plan,many=True)
        return Response({"success":True, "message": "Plan list","plan":serializer.data}, status=status.HTTP_200_OK)
    else:
        return Response({"success":True, "message": "No Plan is found."}, status=status.HTTP_401_UNAUTHORIZED)


@api_view(['POST'])
def domestic_vendor_order_list(request):
    if request.POST.get('domestic_vendor_id') == "":
        return Response({"success":False, "message": "Domestic Vendor Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_vendor_id = request.POST.get('domestic_vendor_id')
    if Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Domestic Vendor Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if Order.objects.filter(domestic_vendor_id=domestic_vendor_id,admin_approve=1):
        order = Order.objects.filter(domestic_vendor_id=domestic_vendor_id)
        lst = []
        for i in order:
            serializer = DomesticOrderSerializer(i)
            x = serializer.data
            product_id = i.product_id.product_id
            xyz = ProductImage.objects.filter(product_id=product_id)
            qwe = ProductImageSerializer(xyz,many=True)
            y = qwe.data
            x["product_id"].update({"product_img":y})
            lst.append(x)
        return Response({"success":True, "message": "Vendor Order list","data":lst}, status=status.HTTP_200_OK)
    else:
        return Response({"success":True, "message": "No product order."}, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['POST'])
def order_detail(request):
    if request.POST.get('order_id') == "":
        return Response({"success":False, "message": "Order Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    order_id = request.POST.get('order_id')
    if Order.objects.filter(order_id=order_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Order Id" }, status=status.HTTP_401_UNAUTHORIZED)
    ot = Order.objects.filter(order_id=order_id).first()
    serializer = DomesticOrderSerializer(ot)
    return Response({"success":True, "message": "Vendor Order detail is here","data":serializer.data}, status=status.HTTP_200_OK)


@api_view(['POST'])
def local_product_list(request):
    if request.POST.get('domestic_buyers_id') == "":
        return Response({"success":False, "message": "Domestic Buyers ID is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_buyers_id = request.POST.get('domestic_buyers_id')
    if Domestic_buyers.objects.filter(domestic_buyers_id=domestic_buyers_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Domestic Buyers ID" }, status=status.HTTP_401_UNAUTHORIZED)
    pt = Product.objects.filter(product_add_by="Domestic",status=1)
    if pt:
        lst = []
        for i in pt:
            serializer = ProductSerializer(i)
            product_id = i.product_id
            x = serializer.data
            if LikeProduct.objects.filter(product_id=product_id,domestic_buyers_id=domestic_buyers_id):
                like = 1
            else:
                like = 0
            x.update({"like":like})
            lst.append(x)
        return Response({"success":True, "message": "Product List","data":lst}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No product found" }, status=status.HTTP_401_UNAUTHORIZED)


@api_view(['POST'])
def add_letter_of_intent(request):
    # serializer = LetterSerializer(data=request.data)
    if request.POST.get('expoters_id') == "":
        return Response({"success":False, "message": "Expoters Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    expoters_id = request.POST.get('expoters_id')
    if Expoters.objects.filter(expoters_id=expoters_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Expoters Id" }, status=status.HTTP_401_UNAUTHORIZED)
    if request.POST.get('date') == "":
        return Response({"success":False, "message": "Date is required" }, status=status.HTTP_400_BAD_REQUEST) 
    date = request.POST.get('date')
    if request.POST.get('address') == "":
        return Response({"success":False, "message": "Address is required" }, status=status.HTTP_400_BAD_REQUEST) 
    address = request.POST.get('address')
    if request.POST.get('expoters_name') == "":
        return Response({"success":False, "message": "Expoters Name is required" }, status=status.HTTP_400_BAD_REQUEST) 
    expoters_name = request.POST.get('expoters_name')
    if request.POST.get('organisation') == "":
        return Response({"success":False, "message": "Organisation is required" }, status=status.HTTP_400_BAD_REQUEST) 
    organisation = request.POST.get('organisation')
    if request.POST.get('product') == "":
        return Response({"success":False, "message": "Product is required" }, status=status.HTTP_400_BAD_REQUEST) 
    product = request.POST.get('product')
    if request.POST.get('quantity') == "":
        return Response({"success":False, "message": "Quantity is required" }, status=status.HTTP_400_BAD_REQUEST) 
    quantity = request.POST.get('quantity')
    if request.POST.get('origin') == "":
        return Response({"success":False, "message": "Origin is required" }, status=status.HTTP_400_BAD_REQUEST) 
    origin = request.POST.get('origin')
    if request.POST.get('specification') == "":
        return Response({"success":False, "message": "Specification is required" }, status=status.HTTP_400_BAD_REQUEST) 
    specification = request.POST.get('specification')
    if request.POST.get('admixture') == "":
        return Response({"success":False, "message": "Ad Mixture is required" }, status=status.HTTP_400_BAD_REQUEST) 
    admixture = request.POST.get('admixture')
    if request.POST.get('color') == "":
        return Response({"success":False, "message": "Color is required" }, status=status.HTTP_400_BAD_REQUEST) 
    color = request.POST.get('color')
    if request.POST.get('mucor') == "":
        return Response({"success":False, "message": "Mucor is required" }, status=status.HTTP_400_BAD_REQUEST) 
    mucor = request.POST.get('mucor')
    if request.POST.get('delivery_time') == "":
        return Response({"success":False, "message": "Delivery Time is required" }, status=status.HTTP_400_BAD_REQUEST) 
    delivery_time = request.POST.get('delivery_time')
    if request.POST.get('destination_port') == "":
        return Response({"success":False, "message": "Destination Port is required" }, status=status.HTTP_400_BAD_REQUEST) 
    destination_port = request.POST.get('destination_port')
    if request.POST.get('payment_term') == "":
        return Response({"success":False, "message": "Payment Term is required" }, status=status.HTTP_400_BAD_REQUEST) 
    payment_term = request.POST.get('payment_term')
    if request.POST.get('previous_customer') == "":
        return Response({"success":False, "message": "Previous Customer is required" }, status=status.HTTP_400_BAD_REQUEST) 
    previous_customer = request.POST.get('previous_customer')
    if request.POST.get('price') == "":
        return Response({"success":False, "message": "Price is required" }, status=status.HTTP_400_BAD_REQUEST) 
    price = request.POST.get('price')
    if request.POST.get('service') == "":
        return Response({"success":False, "message": "Service is required" }, status=status.HTTP_400_BAD_REQUEST) 
    service = request.POST.get('service')
    if request.POST.get('special') == "":
        return Response({"success":False, "message": "Special is required" }, status=status.HTTP_400_BAD_REQUEST) 
    special = request.POST.get('special')
    if request.POST.get('availability') == "":
        return Response({"success":False, "message": "availability is required" }, status=status.HTTP_400_BAD_REQUEST) 
    availability = request.POST.get('availability')
    if request.FILES.getlist('letter_image[]') == "":
        return Response({"success":False, "message": "Letter Image is required" }, status=status.HTTP_400_BAD_REQUEST) 
    letter_image = request.FILES.getlist('letter_image[]')
    loi = Letter.objects.create(expoters_id_id=expoters_id,date=date,address=address,expoters_name=expoters_name,organisation=organisation,product=product,quantity=quantity,origin=origin,specification=specification,admixture=admixture,color=color,mucor=mucor,delivery_time=delivery_time,destination_port=destination_port,payment_term=payment_term,previous_customer=previous_customer,price=price,service=service,special=special,availability=availability)
    l = len(letter_image)
    if l > 4:
        return Response({"success":False, "message": "You only able to insert only four Image" }, status=status.HTTP_401_UNAUTHORIZED)
    for i in range(l):
        image = letter_image[i]
        LetterImage.objects.create(letter_id_id = loi.letter_id, image=image)
    return Response({"success":True, "message": "Letter Of Intent Post successfully"}, status=status.HTTP_200_OK)
    

# def add_product(request):
#     if request.POST.get('domestic_vendor_id') == "":
#         return Response({"success":False, "message": "Domestic Vendors Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     domestic_vendor_id = request.POST.get('domestic_vendor_id')
#     if Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id).first() == None:
#         return Response({"success":False, "message": "Please Enter Valid Domestic Vendors Id" }, status=status.HTTP_401_UNAUTHORIZED)
#     else:
#         dv = Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id).first()
#     if request.POST.get('product_name') == "":
#         return Response({"success":False, "message": "Product Name is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     product_name = request.POST.get('product_name')
#     if request.POST.get('category_id') == "":
#         return Response({"success":False, "message": "Category Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     category_id = request.POST.get('category_id')
#     if Category.objects.filter(category_id=category_id).first() == None:
#         return Response({"success":False, "message": "Please Enter Valid Category Id" }, status=status.HTTP_401_UNAUTHORIZED)
#     if request.POST.get('cost') == "":
#         return Response({"success":False, "message": "Cost is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     cost = request.POST.get('cost')
#     if request.POST.get('about') == "":
#         return Response({"success":False, "message": "Description is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     about = request.POST.get('about')
#     if request.POST.get('variant') == "":
#         return Response({"success":False, "message": "Variant is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     variant = request.POST.get('variant')
#     if request.POST.get('variant_quantity') == "":
#         return Response({"success":False, "message": "Variant Quantity is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     variant_quantity = request.POST.get('variant_quantity')
#     if request.FILES.getlist('product_image[]') == "":
#         return Response({"success":False, "message": "Product Image is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     product_image = request.FILES.getlist('product_image[]')
#     product_add_by = "Domestic"
#     pt = Product.objects.create(product_name=product_name,category_id_id=category_id,cost=cost,about=about,variant=variant,variant_quantity=variant_quantity,date=timezone.now(),product_add_by=product_add_by,domestic_vendor_id_id=domestic_vendor_id)
#     l = len(product_image)
#     if l > 4:
#         return Response({"success":False, "message": "You only able to insert only four Image" }, status=status.HTTP_401_UNAUTHORIZED)
#     for i in range(l):
#         image = product_image[i]
#         ProductImage.objects.create(product_id_id = pt.product_id, image=image)
#     return Response({"success":True, "message": "Product Created" }, status=status.HTTP_200_OK)










class Data(generics.CreateAPIView):
    queryset=LetterImage.objects.all()
    serializer_class=LetterImageSerializer
    def create(self,request):
        if request.POST.get('expoters_id') == "":
            return Response({"success":False, "message": "Expoters Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
        expoters_id = request.POST.get('expoters_id')
        if Expoters.objects.filter(expoters_id=expoters_id).first() == None:
            return Response({"success":False, "message": "Please Enter Valid Expoters Id" }, status=status.HTTP_401_UNAUTHORIZED)
        if request.POST.get('date') == "":
            return Response({"success":False, "message": "Date is required" }, status=status.HTTP_400_BAD_REQUEST) 
        date = request.POST.get('date')
        if request.POST.get('address') == "":
            return Response({"success":False, "message": "Address is required" }, status=status.HTTP_400_BAD_REQUEST) 
        address = request.POST.get('address')
        if request.POST.get('expoters_name') == "":
            return Response({"success":False, "message": "Expoters Name is required" }, status=status.HTTP_400_BAD_REQUEST) 
        expoters_name = request.POST.get('expoters_name')
        if request.POST.get('organisation') == "":
            return Response({"success":False, "message": "Organisation is required" }, status=status.HTTP_400_BAD_REQUEST) 
        organisation = request.POST.get('organisation')
        if request.POST.get('product') == "":
            return Response({"success":False, "message": "Product is required" }, status=status.HTTP_400_BAD_REQUEST) 
        product = request.POST.get('product')
        if request.POST.get('quantity') == "":
            return Response({"success":False, "message": "Quantity is required" }, status=status.HTTP_400_BAD_REQUEST) 
        quantity = request.POST.get('quantity')
        if request.POST.get('origin') == "":
            return Response({"success":False, "message": "Origin is required" }, status=status.HTTP_400_BAD_REQUEST) 
        origin = request.POST.get('origin')
        if request.POST.get('specification') == "":
            return Response({"success":False, "message": "Specification is required" }, status=status.HTTP_400_BAD_REQUEST) 
        specification = request.POST.get('specification')
        if request.POST.get('admixture') == "":
            return Response({"success":False, "message": "Ad Mixture is required" }, status=status.HTTP_400_BAD_REQUEST) 
        admixture = request.POST.get('admixture')
        if request.POST.get('color') == "":
            return Response({"success":False, "message": "Color is required" }, status=status.HTTP_400_BAD_REQUEST) 
        color = request.POST.get('color')
        if request.POST.get('mucor') == "":
            return Response({"success":False, "message": "Mucor is required" }, status=status.HTTP_400_BAD_REQUEST) 
        mucor = request.POST.get('mucor')
        if request.POST.get('delivery_time') == "":
            return Response({"success":False, "message": "Delivery Time is required" }, status=status.HTTP_400_BAD_REQUEST) 
        delivery_time = request.POST.get('delivery_time')
        if request.POST.get('destination_port') == "":
            return Response({"success":False, "message": "Destination Port is required" }, status=status.HTTP_400_BAD_REQUEST) 
        destination_port = request.POST.get('destination_port')
        if request.POST.get('payment_term') == "":
            return Response({"success":False, "message": "Payment Term is required" }, status=status.HTTP_400_BAD_REQUEST) 
        payment_term = request.POST.get('payment_term')
        if request.POST.get('previous_customer') == "":
            return Response({"success":False, "message": "Previous Customer is required" }, status=status.HTTP_400_BAD_REQUEST) 
        previous_customer = request.POST.get('previous_customer')
        if request.POST.get('price') == "":
            return Response({"success":False, "message": "Price is required" }, status=status.HTTP_400_BAD_REQUEST) 
        price = request.POST.get('price')
        if request.POST.get('service') == "":
            return Response({"success":False, "message": "Service is required" }, status=status.HTTP_400_BAD_REQUEST) 
        service = request.POST.get('service')
        if request.POST.get('special') == "":
            return Response({"success":False, "message": "Special is required" }, status=status.HTTP_400_BAD_REQUEST) 
        special = request.POST.get('special')
        if request.POST.get('availability') == "":
            return Response({"success":False, "message": "availability is required" }, status=status.HTTP_400_BAD_REQUEST) 
        availability = request.POST.get('availability')
        if request.FILES.getlist('product_image[]') == "":
            return Response({"success":False, "message": "Product Image is required" }, status=status.HTTP_400_BAD_REQUEST) 
        product_image = request.FILES.getlist('product_image[]')
        loi = Letter.objects.create(expoters_id_id=expoters_id,date=date,address=address,expoters_name=expoters_name,organisation=organisation,product=product,quantity=quantity,origin=origin,specification=specification,admixture=admixture,color=color,mucor=mucor,delivery_time=delivery_time,destination_port=destination_port,payment_term=payment_term,previous_customer=previous_customer,price=price,service=service,special=special,availability=availability)
        serializer = LetterImageSerializer(data=request.data)
        if serializer.is_valid():
            expoters_id = serializer.validated_data.get('expoters_id')
            image = serializer.validated_data.get('image')
        LetterImage.objects.create(expoters_id = expoters_id,image=image)
        return Response({"success":True, "message": "Letter Of Intent Post successfully"}, status=status.HTTP_200_OK)

@api_view(['Get'])
def offer_list(request):
    pt = Offer.objects.all()
    if pt:
        serializer = OfferSerializer(pt,many=True)
        return Response({"success":True, "message": "Offer List","data":serializer.data}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Offer found" }, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['POST'])
def vendor_order_history(request):
    if request.POST.get('domestic_vendor_id') == "":
        return Response({"success":False, "message": "Domestic Vendor Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_vendor_id = request.POST.get('domestic_vendor_id') 
    if Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Domestic Vendor Id" }, status=status.HTTP_401_UNAUTHORIZED)
    order = Order.objects.filter(domestic_vendor_id=domestic_vendor_id,complete_order=1)
    if order:
        serializer = DomesticOrderSerializer(order, many=True)
        return Response({"success":True, "message": "Order Listing.","data":serializer.data}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Order found" }, status=status.HTTP_401_UNAUTHORIZED)
    


@api_view(['POST'])
def vendor_order_ongoing(request):
    if request.POST.get('domestic_vendor_id') == "":
        return Response({"success":False, "message": "Domestic Vendor Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_vendor_id = request.POST.get('domestic_vendor_id') 
    if Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Domestic Vendor Id" }, status=status.HTTP_401_UNAUTHORIZED)
    order = Order.objects.filter(domestic_vendor_id=domestic_vendor_id,complete_order=0,admin_approve=1)
    if order:
        serializer = DomesticOrderSerializer(order, many=True)
        return Response({"success":True, "message": "Order Listing.","data":serializer.data}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Order found" }, status=status.HTTP_401_UNAUTHORIZED)
    

@api_view(['POST'])
def vendor_order_request(request):
    if request.POST.get('domestic_vendor_id') == "":
        return Response({"success":False, "message": "Domestic Vendor Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
    domestic_vendor_id = request.POST.get('domestic_vendor_id') 
    if Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id).first() == None:
        return Response({"success":False, "message": "Please Enter Valid Domestic Vendor Id" }, status=status.HTTP_401_UNAUTHORIZED)
    order = Order.objects.filter(domestic_vendor_id=domestic_vendor_id,admin_approve=1,status=-1)
    if order:
        serializer = DomesticOrderSerializer(order, many=True)
        return Response({"success":True, "message": "Order Listing.","data":serializer.data}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Order found" }, status=status.HTTP_401_UNAUTHORIZED)

# @api_view(['POST'])
# def vendor_order_request(request):
#     if request.POST.get('domestic_vendor_id') == "":
#         return Response({"success": False, "message": "Domestic Vendor Id is required" }, status=status.HTTP_400_BAD_REQUEST) 

#     domestic_vendor_id = request.POST.get('domestic_vendor_id') 

#     domestic_vendor = Domestic_vendors.objects.filter(domestic_vendor_id=domestic_vendor_id).first()

#     if domestic_vendor is None:
#         return Response({"success": False, "message": "Please Enter Valid Domestic Vendor Id" }, status=status.HTTP_401_UNAUTHORIZED)

#     status_filter = request.POST.get('status', 'all')  # Default to 'all' if 'status' is not provided

#     order_query = Order.objects.filter(domestic_vendor_id=domestic_vendor_id, admin_approve=1)

#     if status_filter == '0':
#         order_query = order_query.filter(status=0)
#     elif status_filter == '1':
#         order_query = order_query.filter(status=1)

#     orders = order_query.all()

#     if orders:
#         serializer = DomesticOrderSerializer(orders, many=True)
#         return Response({"success": True, "message": "Order Listing.", "data": serializer.data}, status=status.HTTP_200_OK)
#     else:
#         return Response({"success": False, "message": "No Orders found" }, status=status.HTTP_404_NOT_FOUND)

# @api_view(['POST'])
# def letter_of_intent_list(request):
#     if request.POST.get('expoters_id') == "":
#         return Response({"success":False, "message": "Expoters Id is required" }, status=status.HTTP_400_BAD_REQUEST) 
#     expoters_id = request.POST.get('expoters_id')
#     # if Expoters.objects.filter(expoters_id=expoters_id).first() == None:
#     #     return Response({"success":False, "message": "Please Enter Valid Expoters Id" }, status=status.HTTP_401_UNAUTHORIZED)
#     order = Letter.objects.filter(expoters_id=expoters_id)
#     if order:
#         serializer = LetterSerializer(order, many=True)
#         return Response({"success":True, "message": "Letter Of Instent Listing.","data":serializer.data}, status=status.HTTP_200_OK)
#     else:
#         return Response({"success":False, "message": "No Letter found" }, status=status.HTTP_401_UNAUTHORIZED)


class letter_of_intent_list(APIView):
    def post(self,request,*args,**kwargs):
        expoters_id = request.POST.get('expoters_id')
        order=Letter.objects.filter(expoters_id=expoters_id)
        if order:
            serializer=LetterSerializer(order,many=True)
            return Response({"success":True, "message": "Letter Of Instent Listing.","data":serializer.data}, status=status.HTTP_200_OK)
        else:
            return Response({"success":False, "message": "No Letter found" }, status=status.HTTP_401_UNAUTHORIZED)

@api_view(['POST'])
def Impoter_product_view(request):
    if not request.POST.get('expoters_id'):
        return Response({"success":False,"message":"Expoters Id is required"},status=status.HTTP_400_BAD_REQUEST)
    expoters_id=request.POST.get('expoters_id')
    data=Product.objects.filter(expoters_id=expoters_id)
    if data:
        serializer=ProductSerializer(data,many=True)
        return Response({"success":True, "message": "Expoters Product Listing.","data":serializer.data}, status=status.HTTP_200_OK)
    else:
        return Response({"success":False, "message": "No Expoters Id found" }, status=status.HTTP_401_UNAUTHORIZED)



@api_view(['POST'])
def orderstatusbyvendor(request):
    pass

############################################################# END Of API ##########################################################################









############################################################ ADMIN PANEL #########################################################################







def index(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        context = {
            "st":st,
            "role":"Dashboard"
        }
        return render(request, 'dashboard_nexhub.html',context)
    else:
        return redirect(admin_login)

def admin_category(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        ct = Category.objects.all()
        context = {
            "role":"Category","st":st,'ct':ct
        }
        return render(request, 'category.html',context)
    else:
        return redirect(admin_login)

def category_status_active(request,category_id):
    if request.session.has_key('user'):
        ct = Category.objects.get(category_id=category_id)
        # (ct.status)
        ct.status = 0
        ct.save()
        return redirect(admin_category)
    else:
        return redirect(admin_login)

def category_status_deactive(request,category_id):
    if request.session.has_key('user'):
        ct = Category.objects.get(category_id=category_id)
        # (ct.status)
        ct.status = 1
        ct.save()
        return redirect(admin_category)
    else:
        return redirect(admin_login)


def admin_impoter_register(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        impo = Impoters.objects.filter(status=0)
        context = {
            'impo': impo,
            'role':"Importers Managment",
            "st":st
        }
        return render(request, 'registered_verified.html',context)
    else:
        return redirect(admin_login)


def admin_impoter_verified(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        impo = Impoters.objects.filter(status=1)
        context = {
            'impo': impo,
            'role':"Importers Managment",
            "st":st
        }
        return render(request, 'verifies.html',context)
    else:
        return redirect(admin_login)


def admin_user_log(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        impo = Expoters.objects.all()
        context = {
            'impo': impo,
            'role':"Exporters Managment",
            "st":st
        }
        return render(request, 'user_log.html',context)
    else:
        return redirect(admin_login)

def impoter_status_active(request,importers_id):
    if request.session.has_key('user'):
        pt = Impoters.objects.get(importers_id=importers_id)
        pt.status = 0
        pt.save()
        return redirect(admin_impoter_verified)
    else:
        return redirect(admin_login)
    

def impoter_status_deactive(request,importers_id):
    if request.session.has_key('user'):
        pt = Impoters.objects.get(importers_id=importers_id)
        pt.status = 1
        pt.save()
        return redirect(admin_impoter_register)
    else:
        return redirect(admin_login)


def expoter_status_active(request,expoters_id):
    if request.session.has_key('user'):
        pt = Expoters.objects.get(expoters_id=expoters_id)
        pt.status = 0
        pt.save()
        return redirect(admin_expoter_verified)
    else:
        return redirect(admin_login)
    

def expoter_status_deactive(request,expoters_id):
    if request.session.has_key('user'):
        pt = Expoters.objects.get(expoters_id=expoters_id)
        pt.status = 1
        pt.save()
        return redirect(admin_expoter_registered)
    else:
        return redirect(admin_login)


def admin_expoter_registered(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        expo = Expoters.objects.filter(status=0)
        context = {
            'expo': expo,
            'role':"Exporters Managment",
            "st":st
        }
        return render(request, 'registeredd.html',context)
    else:
        return redirect(admin_login)



def admin_expoter_verified(request):
    if request.session.has_key('user'):
        expo = Expoters.objects.filter(status=1)
        context = {
            'expo': expo,
            'role':"Exporters Management"
        }
        return render(request, 'verified.html',context)
    else:
        return redirect(admin_login)




def domestic_vendor_status_active(request,domestic_vendor_id):
    if request.session.has_key('user'):
        pt = Domestic_vendors.objects.get(domestic_vendor_id=domestic_vendor_id)
        # (ct.status)
        pt.status = 0
        pt.save()
        return redirect(admin_domestic_vendor)
    else:
        return redirect(admin_login)
    

def domestic_vendors_deactive(request,domestic_vendor_id):
    if request.session.has_key('user'):
        pt = Domestic_vendors.objects.get(domestic_vendor_id=domestic_vendor_id)
        # (ct.status)
        pt.status = 1
        pt.save()
        return redirect(admin_domestic_vendor)
    else:
        return redirect(admin_login)


def admin_domestic_vendor(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        domev = Domestic_vendors.objects.all()
        context = {
            'domev': domev,
            'role':"Domestic Vendor"
        }
        return render(request, 'user3.html',context)
    else:
        return redirect(admin_login)


def domestic_buyers_status_active(request,domestic_buyers_id):
    if request.session.has_key('user'):
        pt = Domestic_buyers.objects.get(domestic_buyers_id=domestic_buyers_id)
        # (ct.status)
        pt.status = 0
        pt.save()
        return redirect(admin_domestic_buyers)
    else:
        return redirect(admin_login)
    

def domestic_buyers_status_deactive(request,domestic_buyers_id):
    if request.session.has_key('user'):
        pt = Domestic_buyers.objects.get(domestic_buyers_id=domestic_buyers_id)
        # (ct.status)
        pt.status = 1
        pt.save()
        return redirect(admin_domestic_buyers)
    else:
        return redirect(admin_login)


def admin_domestic_buyers(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        domeb = Domestic_buyers.objects.all()
        context = {
            'domeb': domeb,
            'role':"Domestic Buyers"
        }
        return render(request, 'user4.html',context)
    else:
        return redirect(admin_login)



def admin_login(request):
    if request.method=="POST":
        email = request.POST['email']
        password = request.POST['password']
        if (Super.objects.filter(email_id=email,password=password)):
            st = Super.objects.filter(email_id=email).first()
            user_id = st.super_id
            request.session["user"] = user_id
            return redirect(index)
        else:
            messages.info(request,"User Invalid")
            return redirect("admin_login")
    
    return render(request,"login.html")


def logout(request):
    del request.session['user']
    return redirect(admin_login)


def profile(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        context = {
            "st":st
        }
        return render(request, 'profile.html',context)
    else:
        return redirect(admin_login)

def admin_profile_update(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        st.name = request.POST.get("name")
        st.email_id = request.POST.get("email_id")
        st.password = request.POST.get("password")
        st.phone = request.POST.get("phone")
        if (request.FILES.get('user_img')):
            st.user_img = request.FILES.get('user_img')
        st.save()
        return redirect(profile)
    else:
        return redirect(admin_login)
    

def product_expoter(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        pt = Product.objects.filter(product_add_by="Export")
        lst = []
        for i in pt:
            serializer = ProductSerializer(i)
            created_at = i.created_at
            created_at = datetime.strftime(created_at, '%d %b %Y')
            x = serializer.data
            x.update({"created_at":created_at})
            lst.append(x)
        ct = Category.objects.filter(status=1)
        context = {
            "pt":lst,
            "st":st,
            "ct":ct,
            "role":"Product Management"
        }
        return render(request, 'exporter_product.html',context)
    else:
        return redirect(admin_login)
# def letter_expoter(request?)

def change_product_category(request,product_id):
    category_id = request.POST.get("category_id")
    product = Product.objects.filter(product_id=product_id).first()
    product.category_id_id = category_id
    product.save()
    return redirect(product_expoter)


def domestic_product_category_change(request,product_id):
    category_id = request.POST.get("category_id")
    product = Product.objects.filter(product_id=product_id).first()
    product.category_id_id = category_id
    product.save()
    return redirect(product_domestic)

def letter_intent_expoter_change(request,letter_id):
    expoters_id=request.POST.get("expoters_id")
    letter=Letter.objects.filter(letter_id=letter_id).first()
    letter.expoters_id_id=expoters_id
    letter.save()
    return redirect(add_letter)


def add_sub_admin(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        context = {
            "st":st,
            "role":"Manage Admin"
        }
        return render(request, 'add_sub_admin.html',context)
    else:
        return redirect(admin_login)


def sub_admin_rights(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        admin = Super.objects.all()
        lst = []
        for i in admin:
            serializer = SuperSerializer(i)
            role = i.role.split(",")
            x = serializer.data
            x.update({"role":role})
            lst.append(x)
        context = {
            "admin":lst,
            "st":st,
            "role":"Manage Admin"
        }
        return render(request, 'sub_admin_right.html',context)
    else:
        return redirect(admin_login)


def product_status_active(request,product_id):
    if request.session.has_key('user'):
        pt = Product.objects.get(product_id=product_id)
        # (ct.status)
        pt.status = 0
        pt.save()
        return redirect(product_expoter)
    else:
        return redirect(admin_login)
    

def product_status_deactive(request,product_id):
    if request.session.has_key('user'):
        pt = Product.objects.get(product_id=product_id)
        # (ct.status)
        pt.status = 1
        pt.save()
        return redirect(product_expoter)
    else:
        return redirect(admin_login)


def product_domestic(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        pt = Product.objects.filter(product_add_by="Domestic")
        lst = []
        for i in pt:
            serializer = ProductSerializer(i)
            created_at = i.created_at
            created_at = datetime.strftime(created_at, '%d %b %Y')
            x = serializer.data
            x.update({"created_at":created_at})
            lst.append(x)
        ct = Category.objects.filter(status=1)
        context = {
            "st":st,
            "pt":lst,
            "ct":ct,
            "role":"Product Management"
        }
        return render(request, 'domestic_product.html',context)
    else:
        return redirect(admin_login)
def add_letter(request):
    if request.session.has_key('user'):
        user_id=request.session['user']
        st=Super.objects.filter(super_id=user_id).first()
        data=Letter.objects.all()
        ct=Letter.objects.filter(status=1)
        return render(request,'intent_letter.html',{'data':data,'ct':ct})
    else:
        return redirect(admin_login)

def product_domestic_status_active(request,product_id):
    if request.session.has_key('user'):
        pt = Product.objects.get(product_id=product_id)
        # (ct.status)
        pt.status = 0
        pt.save()
        return redirect(product_domestic)
    else:
        return redirect(admin_login)
    

def product_domestic_status_deactive(request,product_id):
    if request.session.has_key('user'):
        pt = Product.objects.get(product_id=product_id)
        # (ct.status)
        pt.status = 1
        pt.save()
        return redirect(product_domestic)
    else:
        return redirect(admin_login)
def letter_intent_status_active(request,letter_id):
    if request.session.has_key('user'):
        pt=Letter.objects.get(letter_id=letter_id)
        pt.status=0
        pt.save()
        return redirect(add_letter)
    else:
        return redirect(admin_login)

def letter_intet_status_deactive(request,letter_id):
    if request.session.has_key('user'):
        pt=Letter.objects.get(letter_id=letter_id)
        pt.status=1
        pt.save()
        return redirect(add_letter)
    else:
        return redirect(admin_login)
        
def add_new_admin(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        if request.method == "POST":
            name = request.POST.get("name")
            email_id = request.POST.get("email_id")
            phone = request.POST.get("phone")
            password = request.POST.get("password")
            confirm_password = request.POST.get("confirm_password")
            user_img = request.FILES.get("user_img")
            role = request.POST.getlist("role")
            rol = ""
            for i in role:
                rol += i+","
            if password == confirm_password:
                Super.objects.create(name=name,email_id=email_id,phone=phone,password=password,user_img=user_img,role=rol)
                return redirect(add_sub_admin)
            else:
                return redirect(add_sub_admin)
        return redirect(add_sub_admin)
    else:
        return redirect(admin_login)
    

def edit_admin_detail(request,super_id):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        if request.method == "POST":
            name = request.POST.get("name")
            email_id = request.POST.get("email_id")
            phone = request.POST.get("phone")
            user_img = request.FILES.get("user_img")
            role = request.POST.getlist("role")
            rol = ""
            for i in role:
                rol += i+","
            st.name = name
            st.email_id = email_id
            st.phone = phone
            st.role = rol
            if user_img:
                st.user_img = user_img
            st.save()
            return redirect(sub_admin_rights)
        else:
            return redirect(sub_admin_rights)
    else:
        return redirect(admin_login)


def edit_category(request):
    if request.session.has_key('user'):
        category_id = request.POST.get("category_id")
        category_img = request.FILES.get("category_img")
        category_name = request.POST.get("name")
        ct = Category.objects.filter(category_id=category_id).first()
        ct.category_name=category_name
        if category_img:
            ct.category_image = category_img
        ct.save()
        return redirect(admin_category)
    else:
        return redirect(admin_login)


def ads(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        context = {
            "st":st
        }
        return render(request, 'ads.html',context)
    else:
        return redirect(admin_login)
    

def e_notice(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        context = {
            "st":st
        }
        return render(request, 'e-notice.html',context)
    else:
        return redirect(admin_login)
    

def setting(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        context = {
            "st":st
        }
        return render(request, 'setting.html',context)
    else:
        return redirect(admin_login)
    

def order_expoter(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        st = Super.objects.filter(super_id=user_id).first()
        context = {
            "st":st,
            "role":"Order Management"
        }
        return render(request, 'order_expoter.html',context)
    else:
        return redirect(admin_login)


def add_new_category(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        category_image = request.FILES.get("user_img")
        name = request.POST.get("name") 
        Category.objects.create(category_image=category_image,category_name=name)
        return redirect(admin_category)
    else:
        return redirect(admin_login)


def delete_category(request):
    if request.session.has_key('user'):
        user_id = request.session['user']
        category_id = request.POST.get("category_id") 
        print(category_id)
        Category.objects.filter(category_id=category_id).delete()
        return redirect(admin_category)
    else:
        return redirect(admin_login)

# def add_letter(request):
#     data=Letter.objects.all()
#     return render(request,'intent_letter.html',{'data':data})


from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
def update_status(request, letter_id, new_status):
    try:
        letter = Letter.objects.get(pk=letter_id)
        letter.status = new_status
        letter.save()
        return JsonResponse({'status': new_status})
    except Letter.DoesNotExist:
        return JsonResponse({'error': 'Letter not found'}, status=404)

# class save_letter(APIView):
#     def post(self, request):
#         serializer = LetterDataSerializer(data=request.POST)
#         if serializer.is_valid():
#             user = serializer.save()
#             return redirect('/')  
#         return render(request, 'intent_letter.html')
    

class save_letter(APIView):
    def get(self,request):
        letter=Letter.objects.all()
        return render(request,'intent_letter.html',{'letter':letter})
    def post(self, request):
        # expoters_id=request.POST.get('expoters_id')
        # letter_id=request.POST.get('letter_id')
        # letter=Letter.objects.filter(letter_id=letter_id).first()
        # letter.expoters_id_id=expoters_id
        # letter.save()
        # ct=Letter.objects.filter(status=1)
        serializer = LetterDataSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            return redirect('add_letter') 
        return render(request, 'intent_letter.html',{'serializer': serializer})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class RoomList(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    def post(self,request,*args,**kwargs):
        
        mesages = SingleRoomMessage.objects.filter(Room=OuterRef('pk')).order_by('-timestamp')
        unread_mesages_list = SingleRoomMessage.objects.filter(Room=OuterRef('pk'),message_read=False).exclude(User=request.POST['User']).order_by().annotate(count=Func(F('id'), function='Count')).values('count')
        
        SC1=SingleChatRoom.objects.annotate(unread_messages=Subquery(unread_mesages_list)).annotate(recent_message=Subquery(mesages.values('content')[:1])).filter(user1=request.POST['User']).values('unread_messages','recent_message','DateAdded',Room_id=F('id'),importers_id=F('user2_id'),first_name=F('user2__first_name'),last_name=F('user2__last_name'),user_img=F('user2__user_img'))
        SC2=SingleChatRoom.objects.annotate(unread_messages=Subquery(unread_mesages_list)).annotate(recent_message=Subquery(mesages.values('content')[:1])).filter(user2=request.POST['User']).values('unread_messages','recent_message','DateAdded',Room_id=F('id'),importers_id=F('user1_id'),first_name=F('user1__first_name'),last_name=F('user1__last_name'),user_img=F('user1__user_img'))
        
        SC= SC1.union(SC2)
        
        data=SC.order_by('-DateAdded')
        
        return Response({
            'data':data,
            'msg':'Room List',
            'status':200
        })
from django.db.models import F
class ChatHistory(generics.GenericAPIView):
    def post(self,request,*args,**kwargs):
        SingleRoomMessage.objects.filter(Room=request.POST['Room_id'],User=request.POST['User_id']).update(message_read=True)
        
        data_own=SingleRoomMessage.objects.filter(Room=request.POST['Room_id'])
        
        data=data_own 
        data=data.order_by('timestamp').values('content','timestamp','User_id')#,'Status')
        Profile_User2=SingleChatRoom.objects.filter(id=request.POST['Room_id'],user2=request.POST['User_id'])
        Profile_User1=SingleChatRoom.objects.filter(id=request.POST['Room_id'],user1=request.POST['User_id'])
        Profile_User=[]
        if Profile_User2.exists():
            Profile_User=Profile_User2.values(User_id=F('user2_id'),first_name=F('user2__first_name'),last_name=F('user2__last_name'),user_img=F('user2__user_img'))
            # Profile_User=Profile_User2.values()

        if Profile_User1.exists():
            Profile_User=Profile_User1.values(User_id=F('user1_id'),first_name=F('user1__first_name'),last_name=F('user1__last_name'),user_img=F('user1__user_img'))
            pass
        return Response({
            'data':data,
            'profile':Profile_User,
            'msg':'Room List',
            'status':200
        })
import requests, base64
client_ID='AWDIC-9jCMtdjv2Om2jWkUTpCgdphGeLzOSc02Uic0RVFFqTefqMoZH4KMBrU5OINugBqvEpXs90gacT'
client_Secret='EE7_demh38Yh0ob1Tw92lnU2zafMcXyPqQhfJq_Dnj7jBYMIUXsuCSKhi0sO2pVABeftKbYtf4ENoSdU'
class paypaltoken(generics.GenericAPIView):
    def get(self,request,*args,**kwargs):
        url = "https://api.sandbox.paypal.com/v1/oauth2/token"
        data = {
                    "client_id":client_ID,
                    "client_secret":client_Secret,
                    "grant_type":"client_credentials"
                }
        print(data,'data')
        headers = {
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Authorization": "Basic {0}".format(base64.b64encode((client_ID + ":" + client_Secret).encode()).decode())
                }
        print(headers,'headers')
        token = requests.post(url, data, headers=headers)
        print(token,'token')
        return Response({'message':'success','token':token})

def PaypalToken(client_ID, client_Secret):

    url = "https://api.sandbox.paypal.com/v1/oauth2/token"
    data = {
                "client_id":client_ID,
                "client_secret":client_Secret,
                "grant_type":"client_credentials"
            }
    headers = {
                "Content-Type": "application/x-www-form-urlencoded",
                "Authorization": "Basic {0}".format(base64.b64encode((client_id + ":" + client_secret).encode()).decode())
            }

    token = requests.post(url, data, headers=headers)
    return token