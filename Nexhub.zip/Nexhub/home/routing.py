from django.urls import re_path 
from .consumers import ChatConsumer

websocket_urlpatterns = [
    # re_path(r'ws/socket-server/', ChatConsumer.as_asgi())
    re_path(r'ws/socket-server/(?P<token_user_id>\d+)/(?P<other_user_id>\d+)/(?P<chatType>\w+)/$', ChatConsumer.as_asgi()),
    

]