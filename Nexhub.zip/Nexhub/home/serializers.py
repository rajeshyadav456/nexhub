from rest_framework import serializers
from home.models import *

class ImpotersSerializer(serializers.ModelSerializer):
    class Meta:
        model = Impoters
        fields = '__all__'

class ExpotersSerializer(serializers.ModelSerializer):
    class Meta:
        model = Expoters
        fields = '__all__'

class Domestic_vendorsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Domestic_vendors
        fields = '__all__'

class Domestic_buyersSerializer(serializers.ModelSerializer):
    class Meta:
        model = Domestic_buyers
        fields = '__all__'

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'


class ProductImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductImage
        fields = '__all__'

class ProductSerializer(serializers.ModelSerializer):
    product_image = ProductImageSerializer(many=True)
    class Meta:
        model = Product
        fields = '__all__'
        depth = 1


class DomesticVendorProfileSerializer(serializers.ModelSerializer):
    products = ProductSerializer(many=True)
    class Meta:
        model = Domestic_vendors
        fields = '__all__'
        depth = 1


class ElearningSerializer(serializers.ModelSerializer):
    class Meta:
        model = Elearning
        fields = '__all__'


class EcoursesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ecourses
        fields = '__all__'

class DomesticOrderSerializer(serializers.ModelSerializer):
    order_date = serializers.DateTimeField(format="%a, %d %b %Y")
    class Meta:
        model = Order
        fields = "order_id","order_gen","domestic_buyers_id","product_id","quantity","total_cost","order_status","order_date","date1","date2","date3","date4","date5"
        depth = 1


class ExporterOrderSerializer(serializers.ModelSerializer):
    order_date = serializers.DateTimeField(format="%a, %d %b %Y")
    class Meta:
        model = Order
        fields = "order_id","order_gen","importers_id","product_id","quantity","total_cost","order_status","order_date","date1","date2","date3","date4","date5"
        depth = 1


class LikeEcourseSerializer(serializers.ModelSerializer):
    class Meta:
        model = LikeEcourse
        fields = '__all__'
        depth = 1


class LearnmoreSerializer(serializers.ModelSerializer):
    class Meta:
        model = Learn_more
        fields = '__all__'


class CartSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cart
        fields = '__all__'
        depth = 1


class SuperSerializer(serializers.ModelSerializer):
    class Meta:
        model = Super
        fields = '__all__'


class PlanSerializer(serializers.ModelSerializer):
    class Meta:
        model = Plans
        fields = '__all__'


class ShippingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Shipping_type
        fields = '__all__'


class BuyersAddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Buyers_adress
        fields = '__all__'


class BuyersProduct_likeSerializer(serializers.ModelSerializer):
    class Meta:
        model = LikeProduct
        fields = "like_product_id","product_id"


class LetterImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = LetterImage
        fields = '__all__'


class LetterSerializer(serializers.ModelSerializer):
    letter_image = LetterImageSerializer(many=True)
    class Meta:
        model = Letter
        fields = '__all__'


class OfferSerializer(serializers.ModelSerializer):
    class Meta:
        model = Offer
        fields = '__all__'


# class LetterDataSerializer(serializers.Serializer):
#     expoters_id= serializers.PrimaryKeyRelatedField(queryset=Expoters.objects.all())  
#     expoters_id_email_id = serializers.SerializerMethodField()
#     date = serializers.DateField()
#     address = serializers.CharField(max_length=222)
#     expoters_name = serializers.CharField(max_length=30)
#     organisation = serializers.CharField(max_length=30)
#     product = serializers.CharField(max_length=50)
#     quantity = serializers.IntegerField(default=0)
#     origin = serializers.CharField(max_length=100)
#     specification = serializers.CharField(max_length=500)
#     admixture = serializers.FloatField(default=0.0)
#     color = serializers.CharField(max_length=15)
#     mucor = serializers.IntegerField(default=0)
#     delivery_time = serializers.CharField(max_length=15)
#     destination_port = serializers.CharField(max_length=122)
#     payment_term = serializers.CharField(max_length=122)
#     price = serializers.CharField(max_length=5)
#     service = serializers.CharField(max_length=100)
#     special = serializers.CharField(max_length=100)
#     availability = serializers.CharField(max_length=100)
#     previous_customer = serializers.CharField(max_length=122)
#     status = serializers.IntegerField(default=1)

#     def get_expoters_id(self, obj):
#         return obj.expoters_id.email_id if obj.expoters_id else None
    
#     # class Meta:
#     #     model = Letter
#     #     fields = ('expoters_id','date','address','expoters_name','organisation','product','quantity','origin','specification','admixture','color','mucor','delivery_time','destination_port','payment_term','price','service','special','availability','previous_customer','status',)
#     def create(self,validated_data):
#         user=Letter.objects.create(**validated_data)
#         return user  

class LetterDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = Letter
        fields = ('expoters_id','date','address','expoters_name','organisation','product','quantity','origin','specification','admixture','color','mucor','delivery_time','destination_port','payment_term','price','service','special','availability','previous_customer','status',)
   