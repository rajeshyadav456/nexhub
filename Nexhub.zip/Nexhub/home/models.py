from django.db import models
from datetime import datetime,date
from datetime import datetime, timedelta
import json
import django
# Create your models here.
import uuid
from django.utils import timezone
# Create your models here

class Impoters(models.Model):
    importers_id = models.AutoField(primary_key=True)
    role = models.CharField(max_length=122,null=True)
    first_name = models.CharField(max_length=122,null=True)
    last_name = models.CharField(max_length=122,null=True)
    email_id = models.CharField(max_length=122,null=True)
    phone_no = models.CharField(max_length=16,null=True)
    password = models.CharField(max_length=122,null=True)
    user_img = models.FileField(upload_to='', default='')
    referral_code = models.CharField(max_length=122,null=True)
    firebase_token = models.CharField(max_length=500,null=True)
    social_id = models.CharField(max_length=500,null=True)
    gender = models.CharField(max_length=10,null=True)
    status = models.IntegerField(default=1)
    date = models.DateField(auto_now_add=True)
    def __str__(self):
        return f'{self.importers_id} {self.email_id}'

class Expoters(models.Model):
    expoters_id = models.AutoField(primary_key=True)
    role = models.CharField(max_length=122,null=True)
    first_name = models.CharField(max_length=122,null=True)
    last_name = models.CharField(max_length=122,null=True)
    email_id = models.CharField(max_length=122,null=True)
    phone_no = models.CharField(max_length=16,null=True)
    password = models.CharField(max_length=122,null=True)
    user_img = models.FileField(upload_to='', default='')
    referral_code = models.CharField(max_length=122,null=True)
    firebase_token = models.CharField(max_length=500,null=True)
    social_id = models.CharField(max_length=500,null=True)
    gender = models.CharField(max_length=10,null=True)
    subscription = models.IntegerField(default=0)
    business_logo = models.FileField(upload_to='', default='')
    business_cover = models.FileField(upload_to='', default='')
    business_name = models.CharField(max_length=122,null=True)
    about = models.CharField(max_length=1000,null=True)
    store_location = models.CharField(max_length=122,null=True)
    store_name = models.CharField(max_length=122,null=True)
    type_of_product = models.CharField(max_length=300,null=True)
    import_code = models.CharField(max_length=122,null=True)
    business_document = models.FileField(upload_to='', default='')
    status = models.IntegerField(default=1)
    date = models.DateField(auto_now_add=True)
    def __str__(self):
        return f'{self.expoters_id} {self.email_id}'


class Domestic_vendors(models.Model):
    domestic_vendor_id = models.AutoField(primary_key=True)
    role = models.CharField(max_length=122,null=True)
    first_name = models.CharField(max_length=122,null=True)
    last_name = models.CharField(max_length=122,null=True)
    email_id = models.CharField(max_length=122,null=True)
    phone_no = models.CharField(max_length=16,null=True)
    password = models.CharField(max_length=122,null=True)
    user_img = models.FileField(upload_to='', default='')
    referral_code = models.CharField(max_length=122,null=True)
    firebase_token = models.CharField(max_length=500,null=True)
    social_id = models.CharField(max_length=500,null=True)
    gender = models.CharField(max_length=10,null=True)
    subscription = models.IntegerField(default=0)
    business_logo = models.FileField(upload_to='', default='')
    business_cover = models.FileField(upload_to='', default='')
    business_name = models.CharField(max_length=122,null=True)
    store_name = models.CharField(max_length=122,null=True)
    about = models.CharField(max_length=1000,null=True)
    store_location = models.CharField(max_length=122,null=True)
    type_of_product = models.CharField(max_length=122,null=True)
    business_document = models.FileField(upload_to='', default='')
    status = models.IntegerField(default=1)
    date = models.DateField(auto_now_add=True)
    def __str__(self):
        return f'{self.domestic_vendor_id} {self.email_id}'

class Domestic_buyers(models.Model):
    domestic_buyers_id = models.AutoField(primary_key=True)
    role = models.CharField(max_length=122,null=True)
    first_name = models.CharField(max_length=122,null=True)
    last_name = models.CharField(max_length=122,null=True)
    email_id = models.CharField(max_length=122,null=True)
    phone_no = models.CharField(max_length=16,null=True)
    password = models.CharField(max_length=122,null=True)
    user_img = models.FileField(upload_to='', default='')
    referral_code = models.CharField(max_length=122,null=True)
    firebase_token = models.CharField(max_length=500,null=True)
    social_id = models.CharField(max_length=500,null=True)
    gender = models.CharField(max_length=10,null=True)
    status = models.IntegerField(default=1)
    date = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return f'{self.domestic_buyers_id} {self.email_id}'


class Otp(models.Model):
    otp_id = models.AutoField(primary_key=True)
    email_id = models.CharField(max_length=122,null=True)
    otp = models.CharField(max_length=122,null=True)
    status = models.IntegerField(default=1)
    date = models.DateTimeField(auto_now_add=True)


class Category(models.Model):
    category_id = models.AutoField(primary_key=True)
    category_name = models.CharField(max_length=122,null=True)
    category_image = models.FileField(upload_to='', default='')
    status = models.IntegerField(default=1)
    date = models.DateTimeField(blank=True,null=True)



class Product(models.Model):
    product_id = models.AutoField(primary_key=True)
    product_name = models.CharField(max_length=122,null=True)
    expoters_id = models.ForeignKey(Expoters,on_delete=models.CASCADE,null=True)
    domestic_vendor_id = models.ForeignKey(Domestic_vendors,on_delete=models.CASCADE,null=True,related_name="products")
    category_id = models.ForeignKey(Category,on_delete=models.CASCADE)
    cost = models.FloatField(default=0.0)
    about = models.CharField(max_length=800,null=True)
    variant = models.CharField(max_length=122,null=True)
    variant_quantity = models.IntegerField(default=0)
    product_add_by = models.CharField(max_length=20,null=True)
    status = models.IntegerField(default=0)
    is_featured = models.IntegerField(default=0)
    date = models.DateTimeField(auto_now_add=True)
    created_at = models.DateField(auto_now_add=True)


class ProductImage(models.Model):
    product_image_id = models.AutoField(primary_key=True)
    product_id = models.ForeignKey(Product,on_delete=models.CASCADE,related_name='product_image')
    image = models.ImageField(upload_to='product_images/')
    status = models.IntegerField(default=1)
    date = models.DateTimeField(blank=True,null=True)


class Shipping_type(models.Model):
    ship_id = models.AutoField(primary_key=True)
    shipping_title = models.CharField(max_length=50, null=False)
    detail = models.CharField(max_length=300,null=True)
    delivery_day = models.IntegerField(default=0)
    price = models.IntegerField(default=0)
    status = models.IntegerField(default=1)
    create_at = models.DateField(auto_now_add=True)

class Order(models.Model):
    order_id = models.AutoField(primary_key=True)
    order_gen = models.CharField(max_length=10,null=True)
    importers_id = models.ForeignKey(Impoters,on_delete=models.CASCADE,null=True,blank=True)
    domestic_buyers_id = models.ForeignKey(Domestic_buyers,on_delete=models.CASCADE,null=True,related_name="product_orders",blank=True)
    product_id = models.ForeignKey(Product,on_delete=models.CASCADE,related_name='product_detail',null=True,blank=True)
    expoters_id = models.ForeignKey(Expoters,on_delete=models.CASCADE,null=True,blank=True)
    domestic_vendor_id = models.ForeignKey(Domestic_vendors,on_delete=models.CASCADE,null=True,blank=True)
    quantity = models.IntegerField(default=0)
    total_cost = models.FloatField(default=0.0)
    letter_of_intent = models.FileField(upload_to='',default='')
    date1 = models.DateField(null=True,blank=True)
    date2 = models.DateField(null=True,blank=True)
    date3 = models.DateField(null=True,blank=True)
    date4 = models.DateField(null=True,blank=True)
    date5 = models.DateField(null=True,blank=True)
    status = models.IntegerField(default=0)
    quotation = models.IntegerField(default=0)
    order_status = models.IntegerField(default=0)
    complete_order = models.IntegerField(default=0)
    expected_date = models.DateField(null=True,blank=True)
    ship_id = models.ForeignKey(Shipping_type,on_delete=models.CASCADE,null=True,related_name="shiptype",blank=True)
    shipment = models.CharField(max_length=50,null=True,blank=True)
    admin_approve = models.IntegerField(default=0)
    order_date = models.DateTimeField(auto_now_add=True)


class Cart(models.Model):
    cart_id = models.AutoField(primary_key=True)
    product_id = models.ForeignKey(Product,on_delete=models.CASCADE,related_name='cart_product',null=True)
    domestic_buyers_id = models.ForeignKey(Domestic_buyers,on_delete=models.CASCADE,null=True,related_name="domestic_buyers")
    quantity = models.IntegerField(default=0)
    price = models.IntegerField(default=0)
    status = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)



class Elearning(models.Model):
    elearning_id = models.AutoField(primary_key=True)
    elearning_name = models.CharField(max_length=122,null=True)
    about = models.CharField(max_length=500,null=True)
    image = models.FileField(upload_to='',default='')
    status = models.IntegerField(default=1)
    date = models.DateTimeField(auto_now_add=True)


class Ecourses(models.Model):
    ecourses_id = models.AutoField(primary_key=True)
    elearning_id = models.ForeignKey(Elearning,on_delete=models.CASCADE,related_name='elearning')
    ecourses_name = models.CharField(max_length=122,null=True)
    about = models.CharField(max_length=500,null=True)
    image = models.FileField(upload_to='',default='')
    video = models.FileField(upload_to='',default='')
    status = models.IntegerField(default=1)
    date = models.DateTimeField(auto_now_add=True)


class LikeEcourse(models.Model):
    like_id = models.AutoField(primary_key=True)
    ecourses_id = models.ForeignKey(Ecourses,on_delete=models.CASCADE,related_name='ecourses_like')
    expoters_id = models.ForeignKey(Expoters,on_delete=models.CASCADE)


class LikeProduct(models.Model):
    like_product_id = models.AutoField(primary_key=True)
    product_id = models.ForeignKey(Product,on_delete=models.CASCADE,related_name='product_like')
    domestic_buyers_id = models.ForeignKey(Domestic_buyers,on_delete=models.CASCADE,related_name="domestic_buyers_like",blank=True)


# class LikeStore(models.Model):
#     like_product_id = models.AutoField(primary_key=True)
#     expoter = models.ForeignKey(Product,on_delete=models.CASCADE,related_name='product_like')
#     domestic_buyers_id = models.ForeignKey(Domestic_buyers,on_delete=models.CASCADE,related_name="domestic_buyers_like",blank=True)




class Super(models.Model):
    super_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50,null=True)
    email_id = models.CharField(max_length=100,null=True)
    password = models.CharField(max_length=100,null=True)
    phone = models.CharField(max_length=16,null=True)
    role = models.CharField(max_length=500,null=True)
    user_img = models.FileField(upload_to='', default='')
    created_at = models.DateTimeField(auto_now_add=True)
    def set_foo(self, x):
        self.role = json.dumps(x)

    def get_foo(self):
        return json.loads(self.role)

class Learn_more(models.Model):
    learn_more_id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=50,null=True)
    description = models.TextField()
    image = models.FileField(upload_to='',default='')
    status = models.IntegerField(default=1)
    created_at = models.DateTimeField(auto_now_add=True)


class Buyers_adress(models.Model):
    buyers_address_id = models.AutoField(primary_key=True)
    domestic_buyers_id = models.ForeignKey(Domestic_buyers,on_delete=models.CASCADE,null=True,related_name="domestic_buyers_address")
    name = models.CharField(max_length=50,null=True)
    email_id = models.CharField(max_length=70,null=True)
    phone_no = models.CharField(max_length=20,null=True)
    address = models.CharField(max_length=100,null=True)
    zip_code = models.CharField(max_length=10,null=True)
    city = models.CharField(max_length=50,null=True)
    country = models.CharField(max_length=50,null=True)
    by_default = models.IntegerField(default=0)
    created_at = models.DateField(auto_now_add=True)

class Review(models.Model):
    review_id = models.AutoField(primary_key=True)
    order_id = models.ForeignKey(Order,on_delete=models.CASCADE,null=True)
    rate = models.IntegerField(default=0)
    comment = models.CharField(max_length=500,null=True)
    status = models.IntegerField(default=1)
    post_at = models.DateTimeField(auto_now_add=True)

class Plans(models.Model):
    plan_id = models.AutoField(primary_key=True)
    plan_name = models.CharField(max_length=122,null=True)
    price = models.CharField(max_length=200,null=True)
    buying_access = models.CharField(max_length=5,null=True,blank=True)
    selling_access = models.CharField(max_length=5,null=True,blank=True)
    inventory = models.IntegerField(default=0)
    active_duration = models.IntegerField(default=0)
    exportable_containers = models.IntegerField(default=0)
    offtaking_commodities = models.IntegerField(default=0)
    practical_export = models.CharField(max_length=5,null=True,blank=True)
    cluster_export = models.CharField(max_length=5,null=True,blank=True)
    free_warehouse = models.IntegerField(default=0)
    export_doc = models.CharField(max_length=5,null=True,blank=True)
    loan_application = models.CharField(max_length=5,null=True,blank=True)
    social_media = models.CharField(max_length=5,null=True,blank=True)
    in_app_advert = models.CharField(max_length=5,null=True,blank=True)
    event_features = models.CharField(max_length=5,null=True,blank=True)
    status = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)


class Letter(models.Model):
    letter_id = models.AutoField(primary_key=True)
    expoters_id = models.ForeignKey(Expoters,on_delete=models.CASCADE,null=True,blank=True)
    date = models.DateField(null=True,blank=True)
    address = models.CharField(max_length=222,null=True)
    expoters_name = models.CharField(max_length=30,null=True)
    organisation = models.CharField(max_length=30,null=True)
    product = models.CharField(max_length=50,null=True)
    quantity = models.IntegerField(default=0)
    origin = models.CharField(max_length=100,null=True)
    specification = models.CharField(max_length=500,null=True)
    admixture = models.FloatField(default=0.0)
    color = models.CharField(max_length=15,null=True)
    mucor = models.IntegerField(default=0)
    delivery_time = models.CharField(max_length=15,null=True)
    destination_port = models.CharField(max_length=122,null=True)
    payment_term = models.CharField(max_length=122,null=True)
    price = models.CharField(max_length=5,null=True)
    service = models.CharField(max_length=100,null=True)
    special = models.CharField(max_length=100,null=True)
    availability = models.CharField(max_length=100,null=True)
    previous_customer = models.CharField(max_length=122,null=True)
    status = models.IntegerField(default=1)
    created_at = models.DateTimeField(auto_now_add=True)


class LetterImage(models.Model):
    letter_image_id = models.AutoField(primary_key=True)
    letter_id = models.ForeignKey(Letter,on_delete=models.CASCADE,related_name='letter_image')
    image = models.FileField(upload_to='images/')
    status = models.IntegerField(default=1)
    date = models.DateTimeField(blank=True,null=True)


class Offer(models.Model):
    offer_id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=50,null=True)
    about = models.CharField(max_length=500,null=True)
    offer_img = models.FileField(blank=True,null=True)
    status = models.IntegerField(default=0)
    create_at = models.DateTimeField(auto_now_add=True)





class SingleChatRoom(models.Model):
    roomname=models.CharField(max_length=255,blank=False)
    user1=models.ForeignKey(Impoters,on_delete=models.CASCADE,related_name='User1InRoom')
    user2=models.ForeignKey(Impoters,on_delete=models.CASCADE,related_name='User2InRoom')
    DateAdded=models.DateTimeField(default=django.utils.timezone.now)    
    
    def __str__(self):
        return str(self.roomname)
    
class SingleRoomMessage(models.Model):
    User=models.ForeignKey(Impoters,on_delete=models.CASCADE,related_name='SingleUserMessage')
    Room=models.ForeignKey(SingleChatRoom,on_delete=models.CASCADE,related_name='SingleRoom')
    timestamp=models.DateTimeField(auto_now_add=True)
    content=models.TextField(unique=False,blank=False)
    text='text'
    media='media'
    messageTypeChoices=[
        (text,'text'),
        (media,'media')
    ]
    messageType=models.CharField(max_length=255,choices=messageTypeChoices,default='text')
    message_read=models.BooleanField(default=False)
    
    def __str__(self):
        return str(self.content)  